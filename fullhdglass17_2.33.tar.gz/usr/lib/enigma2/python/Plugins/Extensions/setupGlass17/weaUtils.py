from Components.config import config
from socket import socket, AF_INET, SOCK_STREAM
import os
XML_FILE = "/tmp/weather.xml"
ENA_MSN = config.plugins.setupGlass17.par88.value == "MSN"
NO_WEATHER_PICON = "/usr/share/enigma2/hd_glass17/icons/3200.png"
ESSL = False
try:
	import ssl
	ssl._create_default_https_context = ssl._create_unverified_context
	ESSL = True
except: pass

def nigttime(v):		
	try:
		if not config.plugins.setupGlass17.par24.value:
			v = v.replace("27","28").replace("29","30").replace("31","32").replace("27","28").replace("33","34")
	except: pass
	return v
			
def temperature_fix(tt,ena=True):
	if ena and tt[0] != '-' and tt[0] != '0':
		tt = '+' + tt
	return tt+unichr(176).encode("latin-1")
      
def chckUnit():
	a = config.plugins.setupGlass17.par86.value
	return ({False: a, True:config.plugins.setupGlass17.par13.value[0]}[a == "0"])
    
def netChck():
	try:
		chck = socket(AF_INET, SOCK_STREAM)
		chck.settimeout(0.8)
		a = ({False: 'weather.yahoo.com', True:'weather.service.msn.com'}[ENA_MSN])
		b = not bool(chck.connect_ex((a, 80)))
		if not ENA_MSN:
			return b
		elif not b:
			return not bool(chck.connect_ex(('www.msn.com', 80)))
		return b 
	except: pass
	return False
    
def setFcolor(w, c):
	if not 'foregroundColor="' in w:
		return w.replace('<widget', '<widget foregroundColor="%s"' % c) + "\n"
	return w.replace('foregroundColor="%s"' % (w.split('foregroundColor="')[1]).split('"')[0], 'foregroundColor="%s"' % c) + "\n"              			
			
