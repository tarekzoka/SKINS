#######################################################################
#
#    Weather for Enigma2
#    Coded by shamann (c)2018
#
#    inspired by 2boom's YWeather
#    xml from https://query.yahooapis.com
#    xml from http://weather.service.msn.com
#    sunset, sunrise calculated by NOAA formula
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License
#    as published by the Free Software Foundation; either version 2
#    of the License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#    
#######################################################################
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
import time as time1
import os
from Components.config import config
from skin import parseColor
import gettext
from urllib2 import Request, urlopen, URLError, HTTPError
from xml.dom.minidom import parseString
import codecs
from datetime import datetime, date, timedelta, time
from urllib import quote, urlencode
from string import upper
import math
from enigma import eTimer, ePoint
from Tools.LoadPixmap import LoadPixmap
from Plugins.Extensions.setupGlass17.weaUtils import *

PLUGINPATH = "/usr/lib/enigma2/python/Plugins/Extensions/setupGlass17/"
try:
	if config.plugins.setupGlass17.par49.value:
		weather_language = []
		weather_language = config.osd.language.value.split("_")
		if os.path.exists(PLUGINPATH + "locale/%s" % (weather_language[0])):
			_ = gettext.Catalog('weather', PLUGINPATH + 'locale', weather_language).gettext
except: pass
if os.path.isfile(PLUGINPATH + "wea.log"):
	os.system("rm -rf "+PLUGINPATH + "wea.log")
ENA_ANIM = False
try:
	if config.plugins.setupGlass17.par56.value:
		ENA_ANIM = True
except: pass
ENA_W = 0
ENA_C = 0
try:
	if config.plugins.setupGlass17.par93.value != "AutoColors":
		ENA_W = 9999
	if config.plugins.setupGlass17.par94.value != "AutoColors":
		ENA_C = -9999
except: pass
NO_WIND_PICON = "/usr/share/enigma2/hd_glass17/icons/no-wind.png"
UNKNOWN_STATE = _("...N/A...")
UNKNOWN_STATE_TEMP = "--" + '%s' % unichr(176).encode("latin-1")
DICT_DAYS = {'Sun':_('Sun'), 'Mon':_('Mon'), 'Tue':_('Tue'), 'Wed':_('Wed'), 'Thu':_('Thu'), 'Fri':_('Fri'), 'Sat':_('Sat')}
DICT_DATE = {'Jan':_('January'), 'Feb':_('February'), 'Mar':_('March'), 'Apr':_('April'), 'May':_('May'), 'Jun':_('Jun'), 'Jul':_('Jul'), 'Aug':_('August'), 'Sep':_('September'), 'Oct':_('October'), 'Nov':_('November'), 'Dec':_('December'),
'1':_('January'), '2':_('February'), '3':_('March'), '4':_('April'), '5':_('May'), '6':_('Jun'), '7':_('Jul'), '8':_('August'), '9':_('September'), '10':_('October'), '11':_('November'), '12':_('December')}
DICT_TEXT = {'Light Snow':_('Light Snow Shower'), 'Snow Showers':_('Light Snow Shower'), 'Foggy':_('Fog'), 'Fog':_('Fog'), 'Sun':_('Sunny'), 'Clouds':_('Cloudy'), 'Light Rain with Thunder':_('Light Rain with Thunder'), 'Drizzle':_('Drizzle'), 'Showers in the Vicinity':_('Showers in the Vicinity'),
'Rain Shower':_('Rain Shower'), 'Thunderstorm':_('Thunderstorm'), 'Thunder in the Vicinity':_('Thunder in the Vicinity'), 'Thundershowers':_('Thundershowers'), 'Light Drizzle':_('Light Drizzle'), 'Thunder':_('Thunder'), 'Light Rain Shower':_('Light Rain Shower'),
'Isolated Thunderstorms':_('Isolated Thunderstorms'), 'Scattered Thunderstorms':_('Scattered Thunderstorms'), 'AM':_('AM'), 'PM':_('PM'), 'Mostly Clear':_('Mostly Clear'), 'Snow':_('Snow'), 'Thunderstorms':_('Thunderstorms'), 'Wind':_('Wind'), 'Windy':_('Wind'), 'T-Storms':_('Thunderstorms'),
'Showers':_('Showers'), 'Light Snow Shower':_('Light Snow Shower'), 'Rain':_('Rain'), 'Mostly Sunny':_('Mostly Sunny'), 'Sunny':_('Sunny'), 'Clearing':_('Clear'), 'Clear':_('Clear'), 'Thunderstorms':_('Thunderstorms'), 'Partly Cloudy':_('Partly Cloudy'), 'Mostly Cloudy':_('Mostly Cloudy'),
'Scattered Showers':_('Scattered Showers'), 'Few Showers':_('Few Showers'), 'Light Rain':_('Light Rain'), 'Showers':_('Showers'), 'Cloudy':_('Cloudy'), 'Fair':_('Fair'), 'Scattered Snow Showers':_('Scattered Snow Showers'), 'Wintry Mix':_('Wintry Mix'), 'Icy':_('Ice'), 'Ice':_('Ice'),
'Breezy':_('Breezy'), 'Rain Showers':_('Rain Shower'), 'Freezing Drizzle':_('Freezing Drizzle'), 'Freezing Rain':_('Freezing Rain'), 'Partly Sunny':_('Partly Cloudy'), 'Light Rain and Snow':_('Light Rain')+' / '+_('Snow'), 'Heavy Rain':_('Rain'), 'Rain And Snow':_('Rain')+' / '+_('Snow'), 'Rain and Snow':_('Rain')+' / '+_('Snow')}
#######################################################################
def convToC(t):
	return int((t - 32) * 5.0/9.0)

class ColorLabel(Label):
	def __init__(self, text=""):
		Label.__init__(self, text)

	def colorA(self,v):
		if self.instance:
			cc = ("#FEFEFE","#E5E5E5","#B9B9B9","#CC99CC","#CC66CC","#CC00CC","#9933CC","#6666CC","#3377FF","#1155FF","#0066FF","#0099FF","#00BDFE","#AAFFFF","#00F7C6","#18D78C","#00A963","#27A727","#2AC72A","#00FD00","#CBFE00","#FEFE00","#ECEC7D",
			"#E4CC66","#DCAE49","#FFAA00","#FF5500","#FF2200","#FF0000","#FF0033","#FF3333","#FF3366")
			if v > 35:
				v = 35
			elif v < -26:
				v = -26
			v += 26
			if v != 0:
				i = int(v/2)
				if i*2 != v:
					i += 1
			else:
				i = 0
			self.instance.setForegroundColor(parseColor(cc[i])) 

	def colorW(self):
		if self.instance:
			self.instance.setForegroundColor(parseColor(config.plugins.setupGlass17.par93.value))

	def colorC(self):
		if self.instance:
			self.instance.setForegroundColor(parseColor(config.plugins.setupGlass17.par94.value))

	def colorF(self):
		if self.instance:
			self.instance.setForegroundColor(parseColor(config.plugins.setupGlass17.par95.value))
#######################################################################
class WeatherScreen(Screen):                  

	def __init__(self, session, skin_type):
		Screen.__init__(self, session)
		self.skin_type = skin_type
		from Plugins.Extensions.setupGlass17.g17weather_skins import *
		typeSkin = "skin_%s" % self.skin_type
		self.skin = vars()[typeSkin]
		if config.plugins.setupGlass17.par174.value != "AutoColors" or config.plugins.setupGlass17.par175.value != "AutoColors":
			tmp = self.skin.split("\n")
			a = ""
			for i in tmp:
				if 'name="Weather_Date' in i and config.plugins.setupGlass17.par174.value != "AutoColors":
					a += setFcolor(i,config.plugins.setupGlass17.par174.value)
				elif 'name="Weather_state' in i and config.plugins.setupGlass17.par175.value != "AutoColors":
					a += setFcolor(i,config.plugins.setupGlass17.par175.value)
				else:
					a += i + "\n"
			self.skin = a
		self.LIGHT = False
		if self.skin_type in ("2","4"):	
			self.LIGHT = True
		self.RESET_VALUES = UNKNOWN_STATE+"\n"+UNKNOWN_STATE+"\n"+UNKNOWN_STATE+"\n"+UNKNOWN_STATE+"\n"+UNKNOWN_STATE+"\n"+UNKNOWN_STATE+"\n"+UNKNOWN_STATE+ "%s" % ({True:"\n"+UNKNOWN_STATE, False:""}[self.LIGHT])
		try:	
			if config.plugins.setupGlass17.par71.value:
				from keymapparser import readKeymap
				from GlobalActions import globalActionMap
				readKeymap("/usr/lib/enigma2/python/Plugins/Extensions/setupGlass17/keymap3.xml")
				globalActionMap.actions['eventNextPrev'] = self.changeCity
		except: pass
		self.TITLE_S = self.readTitleType()
		self['Weather_items'] = Label(self.setLabels())
		self['Weather_values'] = Label(self.RESET_VALUES)
		self['Weather_wind'] = Pixmap()
		self['Weather_wind_label'] = Label(_("Wind direction"))
		self['Weather_sunrise'] = Label(UNKNOWN_STATE)
		self['Weather_sunset'] = Label(UNKNOWN_STATE)		
		for x in range(0,6):
			self['Weather_picon%s' % x] = Pixmap()
			self['Weather_Temperature%s' % x] = ColorLabel(UNKNOWN_STATE_TEMP)
			if x != 0:
				self['Weather_Temperaturelow%s' % x] = ColorLabel(UNKNOWN_STATE_TEMP)
				self['Weather_Date%s' % x] = Label(UNKNOWN_STATE)
			self['Weather_state%s' % x] = Label(UNKNOWN_STATE)
		self.onShow.append(self.__wakeup1)
		self.onHide.append(self.__standby)
		self.weaTimer = eTimer()
		self.att = 1
		try:
			self.weaTimer_conn = self.weaTimer.timeout.connect(self.__wakeup)
		except AttributeError:
			self.weaTimer.timeout.get().append(self.__wakeup)
		if ENA_ANIM:
			self.animTimer = eTimer()
			try:
				self.animTimer_conn = self.animTimer.timeout.connect(self.__runAnim)
			except AttributeError:
				self.animTimer.timeout.get().append(self.__runAnim)		
		self.units = chckUnit()
		self.remainingTime = int(config.plugins.setupGlass17.par87.value)
		self.enaNC = True
		self.defCity = config.plugins.setupGlass17.par13.value
		self.__atFirst = True
		self.onLayoutFinish.append(self.fixMSNlayout)
		if "w" in config.plugins.setupGlass17.par78.value:
			from Components.ActionMap import ActionMap
			self["actions"] = ActionMap(["ColorActions", "SetupActions", "DirectionActions"],
			{
            "green": self.close,
            "red": self.close,
            "ok": self.close,
            "cancel": self.close,
            "yellow": self.close,
            "blue": self.close
			}, -2)            
                                                                     	
	def fixMSNlayout(self):
		self.resetWeather_values("", False)
		if self.__atFirst and not self.LIGHT and ENA_MSN and not config.plugins.setupGlass17.par92.value:
			self.__atFirst = False
			tt = {}
			for i in ('Weather_picon','Weather_Temperature','Weather_Temperaturelow','Weather_Date','Weather_state'):
				self['%s5' % i].hide()
				tt['%s1X' % i] = self['%s1' % i].instance.position().x()
				tt['%s5X' % i] = self['%s5' % i].instance.position().x()
				tt['%s5Y' % i] = self['%s5' % i].instance.position().y()
				tt['%s5W' % i] = self['%s5' % i].instance.size().width()
				f = ((tt['%s5X' % i]-tt['%s1X' % i] - 3*tt['%s5W' % i])/3) + tt['%s5W' % i]
				self['%s4' % i].move(ePoint(tt['%s5X' % i], tt['%s5Y' % i]))
				self['%s3' % i].move(ePoint(2*f + tt['%s1X' % i], tt['%s5Y' % i]))
				self['%s2' % i].move(ePoint(f + tt['%s1X' % i], tt['%s5Y' % i]))
			tt = None
		for x in range(0,6):
			try:
				self['Weather_picon%s' % x].instance.setScale(1)
			except: pass
            				
	def readTitleType(self):
		self.TITLE_S = False
		try:
			if config.plugins.setupGlass17.par173.value == "s":
				self.TITLE_S = True
		except: pass
		return self.TITLE_S and not self.LIGHT

	def setLabels(self):
		if self.TITLE_S:
			a = _("Location")+":\n" +_("Wind")+":\n"+_("Wind direction")+":\n"+_("Humidity")+":\n"+({False:_("Visibility"), True:_("Geo position")}[ENA_MSN])+":\n"+({False:_("Pressure"), True:_("Feels like")}[ENA_MSN])+":"
		else:
			a = "%s" % ({False:_("City")+":\n"+_("Location")+":\n", True:""}[self.LIGHT]) +_("Wind")+":\n"+_("Wind direction")+":\n"+_("Humidity")+":\n"+({False:_("Visibility"), True:_("Geo position")}[ENA_MSN])+":\n"+({False:_("Pressure"), True:_("Feels like")}[ENA_MSN])+":"+ "%s" % ({True:"\n"+_("Sunrise")+":\n"+_("Sunset")+":\n"+_("Update")+":", False:""}[self.LIGHT])
		return a

	def changeCity(self):
		config.plugins.setupGlass17.par13.handleKey(1)
		if not ENA_MSN:
			new = 0
			while(new < 100):
				req = config.plugins.setupGlass17.par13.value[1:]
				if req.startswith("wc:") or req.startswith("fr:"):
					config.plugins.setupGlass17.par13.handleKey(1)
					new += 1
				else:
					new = 1000
		self.att = 1
		self.__wakeup()

	def __standby(self):
		if self.weaTimer.isActive():
			self.weaTimer.stop()
		if ENA_ANIM:
			if self.animTimer.isActive():
				self.animTimer.stop()
			self.pics = None	
			self.slide = None	
		if self.defCity != config.plugins.setupGlass17.par13.value:
			config.plugins.setupGlass17.par13.value = self.defCity
				
	def __wakeup1(self):
		self.TITLE_S = self.readTitleType()
		self['Weather_items'].setText(self.setLabels())
		self.att = 1
		self.defCity = config.plugins.setupGlass17.par13.value
		self.__wakeup()

	def __wakeup(self):
		def fixDate(d):
			a = d.split()
			if len(a) == 3:
				for ii in (1,2):
					if len(a[ii]) == 2 and a[ii][0] == "0":
						a[ii] = a[ii][1]
				d = "%s. %s %s" % (a[2],a[1],a[0])
			return d
		def parse_line(line, what):
			def parse_AM_PM(txt):
				ttmp = txt.split(' ')
				ttmptxt = txt.replace('AM ','').replace('PM ','')
				if len(ttmp) == 2 and DICT_TEXT.has_key(ttmp[1]) and DICT_TEXT.has_key(ttmp[0]):
					return "%s %s" % (DICT_TEXT.get(ttmp[0]), DICT_TEXT.get(ttmp[1]))
				elif len(ttmp) == 3 and DICT_TEXT.has_key(ttmptxt) and DICT_TEXT.has_key(ttmp[0]):
					return "%s %s" % (DICT_TEXT.get(ttmp[0]), DICT_TEXT.get(ttmptxt))
				return txt
			if not ENA_MSN:
				txt = line.split(what)[1].split('"')[1]			
			else:
				txt = line
			if what == "day" and DICT_DAYS.has_key(txt):
				return DICT_DAYS.get(txt)
			elif what == "sunrise" or what == "sunset" :
				if "pm" in txt or "am" in txt:
					timeFull = txt.lower()
					txt = txt.replace(("pm").lower(),"").replace(("am").lower(),"").replace(" ","")
					time = txt.split(':')
					if len(time[1]) == 1:
						time[1] += "0"
					if "pm" in timeFull and not "12" in time[0]:
						return "%s:%s" % (int(time[0])+12, time[1])
					elif "am" in timeFull and "12" in time[0]:
						return "0:%s" % time[1]
					return txt
			elif what == "country":
				return line.split('country="')[1].split('"')[0]
			elif what == "date":
				ttmp = txt.split(' ')
				if len(ttmp) == 3 and DICT_DATE.has_key(ttmp[1]):
					return "%s %s %s" % (ttmp[0], DICT_DATE.get(ttmp[1]), ttmp[2])
				elif len(ttmp) == 7 and DICT_DAYS.has_key(ttmp[0][:-1]) and DICT_DATE.has_key(ttmp[2]):
					timeFull = ttmp[4]
					time = ttmp[4].split(':')
					if "pm" in ttmp[5].lower() and not "12" in time[0]:
						timeFull = "%s:%s" % (int(time[0])+12, time[1])
					elif "am" in ttmp[5].lower() and "12" in time[0]:
						timeFull = "0:%s" % time[1]
					self.timeUpdate = "%s %s" % (timeFull, ttmp[6])
					return "%s, %s %s %s, %s %s" % (DICT_DAYS.get(ttmp[0][:-1]), ttmp[1], DICT_DATE.get(ttmp[2]), ttmp[3], timeFull, ttmp[6])
				else:
					return txt
			elif what == "text":
				txt = txt.replace(" Early","").replace(" Late","")
				if DICT_TEXT.has_key(txt):
					return DICT_TEXT.get(txt)
				elif ('am' in txt.lower() or 'pm' in txt.lower()) and not '/' in txt:
					return parse_AM_PM(txt)
 				elif '/' in txt:
					ttmp = txt.split('/')
					ret = ""
					for x in range(0, len(ttmp)):
						if DICT_TEXT.has_key(ttmp[x]):
							ret += "%s / " % DICT_TEXT.get(ttmp[x])
						elif 'am' in ttmp[x].lower() or 'pm' in ttmp[x].lower():
							ret += "%s / " % parse_AM_PM(ttmp[x])              
						else:
							ret += "%s / " % ttmp[x]
					if ret != "":
						return ret[:-3]
					return _(txt)
			if txt != "":
				return txt
			else:
				return UNKNOWN_STATE
		def setColor(idx, temp, x, c):
			if self.units == "f":
				temp = convToC(temp)
				a = convToC(config.plugins.setupGlass17.par149.value)
				b = convToC(config.plugins.setupGlass17.par150.value)
			else:
				a = config.plugins.setupGlass17.par96.value
				b = config.plugins.setupGlass17.par97.value
			if c == 9999:			
				if config.plugins.setupGlass17.par95.value != "None" and temp < a:
					self['Weather_Temperature%s%s' % (x, idx)].colorF()
				else:
					self['Weather_Temperature%s%s' % (x, idx)].colorW()
			elif c == -9999:			
				if config.plugins.setupGlass17.par95.value != "None" and temp > b:
					self['Weather_Temperature%s%s' % (x, idx)].colorF()
				else:
					self['Weather_Temperature%s%s' % (x, idx)].colorC()
			else:			
				self['Weather_Temperature%s%s' % (x, idx)].colorA(temp)
		def download_xml():
			os.system("rm -rf %s" % XML_FILE)
			er = ""
			if netChck():
				self.units = chckUnit()
				req = config.plugins.setupGlass17.par13.value[1:]
				if ENA_MSN:
					if req.startswith("wc:") or req.startswith("fr:"):
						req = "wealocations="+req
					else:						
						req = "weasearchstr="+quote(config.plugins.setupGlass17.par13.getText())
					req = "http://weather.service.msn.com/data.aspx?src=outlook&weadegreetype=%s&culture=en-us&%s" % (self.units.upper(), req)
				else:
					if not req.startswith("wc:") and not req.startswith("fr:"):
						query = "select * from weather.forecast where woeid=%s and u='%s'" % (req, self.units)
						req = "https://query.yahooapis.com/v1/public/yql?" + urlencode({'q':query}) + "&format=xml"
					else:
						req = None
						er = _('Error') + ": woeid " + _('is not defined')
				if req is not None:
					data = None
					req = Request(req)
					try:
						if ESSL and not ENA_MSN and config.plugins.setupGlass17.par143.value:
							response = urlopen(req, timeout = 5, context=ssl._create_unverified_context())
						else:
							response = urlopen(req, timeout = 5)
					except HTTPError as e:
						er = _('Error') + ": " + str(e)
					except URLError as e:
						er = _('Error') + ": " + str(e)
					except: er = _('Error') + ": " + _("Website data reading timeout")
					else:
						data = response.read()
						response.close()
					if data is not None:
						if not ENA_MSN:
							data = data.replace("/>","\n")
						localFile = open(XML_FILE, 'wb')
						localFile.write(data)
						localFile.close()
					elif er == "":
						er = _('Error') + ": " + _("None data received from website")
			else:
				return _('Error') + ": " + _("Website is not responding")
			return er.replace('>','').replace('<','')
		self.weaTimer.stop()
		if not self.enaNC:
			return
		self.enaNC = False
		weather_dict = {'feelslike':UNKNOWN_STATE, 'long':UNKNOWN_STATE, 'lat':UNKNOWN_STATE, 'sunrise':UNKNOWN_STATE, 'sunset':UNKNOWN_STATE, 'wind_direction':UNKNOWN_STATE, 'templow5':UNKNOWN_STATE_TEMP, 'templow1':UNKNOWN_STATE_TEMP, 'templow2':UNKNOWN_STATE_TEMP, 'templow3':UNKNOWN_STATE_TEMP, 'templow4':UNKNOWN_STATE_TEMP, 'date5':UNKNOWN_STATE, 'date0':UNKNOWN_STATE, 'date1':UNKNOWN_STATE, 'date2':UNKNOWN_STATE, 'date3':UNKNOWN_STATE, 'date4':UNKNOWN_STATE, 'city':UNKNOWN_STATE, 'country':UNKNOWN_STATE, 'wind':UNKNOWN_STATE, 'humidity':UNKNOWN_STATE, 'visibility':UNKNOWN_STATE, 'pressure':UNKNOWN_STATE, 'text0':UNKNOWN_STATE, 'temp0':UNKNOWN_STATE_TEMP, 'picon0':"3200", 'text1':UNKNOWN_STATE, 'temp1':UNKNOWN_STATE_TEMP, 'picon1':"3200", 'text2':UNKNOWN_STATE, 'temp2':UNKNOWN_STATE_TEMP, 'picon2':"3200", 'text3':UNKNOWN_STATE, 'temp3':UNKNOWN_STATE_TEMP, 'picon3':"3200", 'text4':UNKNOWN_STATE, 'temp4':UNKNOWN_STATE_TEMP, 'picon4':"3200", 'text5':UNKNOWN_STATE, 'temp5':UNKNOWN_STATE_TEMP, 'picon5':"3200"}
		units_dict = {'wind':'', 'visibility':'', 'pressure':''}
		self.timeUpdate = UNKNOWN_STATE
		a = _('Error') + ": " + _("City") + " " + _('is not defined')
		try:
			lt = int(config.plugins.setupGlass17.par87.value)
			self.remainingTime = lt
			if config.plugins.setupGlass17.par13.value != "None":
				aa = config.plugins.setupGlass17.par152.value
				if config.plugins.setupGlass17.par89.value != config.plugins.setupGlass17.par13.value:
					config.plugins.setupGlass17.par89.value = config.plugins.setupGlass17.par13.value 
					a = download_xml()
				elif aa[0] != config.plugins.setupGlass17.par86.value:
					config.plugins.setupGlass17.par152.value = config.plugins.setupGlass17.par86.value + aa[1]
					a = download_xml()
				elif os.path.isfile(XML_FILE):
					fileTime = int((time1.time() - os.stat(XML_FILE).st_mtime)/60)
					if fileTime >= lt or os.path.getsize(XML_FILE) < 1000:
						a = download_xml()
					else:
						self.remainingTime = lt - fileTime
				else:
					a = download_xml()
			else:
				self.resetWeather_values(a, False)
				return			
		except: return
		if not os.path.isfile(XML_FILE):
			os.system("echo -e 'None' >> %s" % XML_FILE)
			self.resetWeather_values(a)
			return
		if ENA_MSN:
			data = dom = dom0 = None
			try:
				data = (open(XML_FILE).read()).replace('\xc2\x86', '').replace('\xc2\x87', '').decode("utf-8", "ignore").encode("utf-8") or ""			
				data =  codecs.decode(data, 'UTF-8')
				dom = parseString(data)
				dom0 = dom.getElementsByTagName("weather")[0]			
			except:	pass
			if data is not None and dom is not None and dom0 is not None:
				idx = 1
				for x in dom0.getElementsByTagName('forecast'):
					ena = -1
					if not config.plugins.setupGlass17.par92.value:
						try:
							w = x.getAttribute("date") or datetime.now().strftime("%Y-%m-%d")
							ena = (datetime.now()-datetime.strptime("%s-23-59" % w,"%Y-%m-%d-%H-%M")).days
						except: pass
					if ena < 0 and idx < 6:
						try:
							w = str(x.getAttribute("high"))
							weather_dict["temp%s" % idx] = temperature_fix(w)
							setColor(idx, int(w), "", ENA_W)
							w = str(x.getAttribute("low"))
							weather_dict["templow%s" % idx] = temperature_fix(w)        
							setColor(idx, int(w), 'low', ENA_C)
							weather_dict["date%s" % idx] = "%s\n%s" % (parse_line(str(x.getAttribute("shortday")), 'day'), parse_line(str(fixDate(x.getAttribute("date").replace("-"," "))), 'date'))
							weather_dict["picon%s" % idx] = nigttime(parse_line(str(x.getAttribute("skycodeday")), 'code'))
							weather_dict["text%s" % idx] = parse_line(str(x.getAttribute("skytextday")), 'text')
						except: pass
						idx += 1
				d = dom.getElementsByTagName("weather")
				if len(d) != 0:
					w = str(d[0].getAttribute("weatherlocationname"))
					try:
						weather_dict["country"] = ({False:w, True:" ".join((w.split(",")[1]).strip().split())}["," in w])
					except: pass
					weather_dict["long"] = str(d[0].getAttribute("long"))
					weather_dict["lat"] = str(d[0].getAttribute("lat"))
					try:
						xx = float(weather_dict["long"])
						yy = float(weather_dict["lat"])
						daylight = time1.localtime().tm_isdst
						julian_day = date.today() - date(1999, 1, 1) + timedelta(2451545)
						nstar = julian_day.days - 2451545.0009 - (xx /360)
						n = nstar + 0.5
						Jstar = 2451545.0009 + (xx /360) + n
						M = (357.5291 + 0.98560028 * (Jstar - 2451545)) % 360
						Mradians = M * math.pi/180
						C = 1.9148 * math.sin(Mradians) + 0.02 * math.sin(2*Mradians) + 0.0003 * math.sin(3*Mradians)
						l = (M + 102.9372 + C + 180) % 360
						Jtransit = Jstar + 0.0053*math.sin(Mradians) - 0.0069 * math.sin(2 * l * math.pi/180)
						delta = math.asin(math.sin(l*math.pi/180) * math.sin(23.45 * math.pi/180)) * 180/math.pi
						w = math.acos((math.sin(-0.83 * math.pi/180) - (math.sin(yy * math.pi/180) * math.sin(delta * math.pi/180)))/(math.cos(yy * math.pi/180) * math.cos(delta * math.pi/180)))*180/math.pi
						Jset = 2451545.0009 + (w + xx)/360 + n + (0.0053 * math.sin(Mradians)) - 0.0069 * math.sin(2 * l * math.pi/180)
						Jrise = Jtransit - (Jset - Jtransit)
						weather_dict['sunset'] = time.strftime(time(int(math.floor((Jset-julian_day.days) * 24) + daylight), int(math.floor(((Jset-julian_day.days) * 24 - math.floor((Jset-julian_day.days) * 24)) * 60))), '%H:%M')
						weather_dict['sunrise'] = time.strftime(time(int(math.floor((Jrise-julian_day.days) * 24) + daylight), int(math.floor(((Jrise-julian_day.days) * 24 - math.floor((Jrise-julian_day.days) * 24)) * 60))), '%H:%M')
						if len(weather_dict['sunrise']) == 5 and weather_dict['sunrise'][0] == '0':
							weather_dict['sunrise'] = weather_dict['sunrise'][1:]
					except: pass
				d = dom.getElementsByTagName("current")
				if len(d) != 0:
					weather_dict["feelslike"] = temperature_fix(str(d[0].getAttribute("feelslike")))
					w = str(d[0].getAttribute("temperature"))
					weather_dict["temp0"] = temperature_fix(w)            
					setColor("0", int(w), "", ENA_W)
					weather_dict["humidity"] = str(d[0].getAttribute("humidity")) + " %"
					w = d[0].getAttribute("winddisplay").replace("kmph","km/h") 
					w = w.split()
					units_dict = {'Northwest':(_('NW'),'NW'), 'Southwest':(_('SW'),'SW'), 'Southeast':(_('SE'),'SE'), 'Northeast':(_('NE'),'NE'), 'South':(_('S'),'S'), 'North':(_('N'),'N'), 'West':(_('W'),'W'), 'East':(_('E'),'E')}
					w_directPix = "U"
					try:
						weather_dict["wind"] = str("%s %s" % (w[0],w[1]))
						weather_dict["wind_direction"] = units_dict[w[2]][0]
						w_directPix = units_dict[w[2]][1]
					except: pass
					weather_dict["text0"] = parse_line(str(d[0].getAttribute("skytext")), 'text')
					weather_dict["picon0"] = nigttime(parse_line(str(d[0].getAttribute("skycode")), 'code'))
					weather_dict["date0"] = str("%s, %s" % (d[0].getAttribute("observationtime")[:5],parse_line(d[0].getAttribute("shortday"), 'day')))	
		else:
			idx = 1
			w_directPix = 'X'
			dd = {'Jan':'1', 'Feb':'2', 'Mar':'3', 'Apr':'4', 'May':'5', 'Jun':'6', 'Jul':'7', 'Aug':'8', 'Sep':'9', 'Oct':'10', 'Nov':'11', 'Dec':'12',}
			req = open(XML_FILE).read()
			if "/>" in req:
				req = req.replace("/>","\n")
			for line in req.split("\n"):
				if line.find("<yweather:location") > -1:
					weather_dict['country'] = parse_line(line, 'country')
				elif line.find("<yweather:astronomy") > -1:
					weather_dict['sunrise'] = parse_line(line, 'sunrise')
					weather_dict['sunset'] = parse_line(line, 'sunset')
				elif line.find("<yweather:units") > -1:
					units_dict['wind'] = parse_line(line, 'speed')
					units_dict['visibility'] = parse_line(line, 'distance')
					units_dict['pressure'] = (parse_line(line, 'pressure')).replace("mb","hPa")
				elif line.find("<yweather:wind") > -1:
					try:
						weather_dict['wind'] = parse_line(line, 'speed')
						direct = int(parse_line(line, 'direction'))
						if direct >= 0 and direct <= 28:
							w_direct = _('N')
							w_directPix = 'N'
						elif direct >= 29 and direct <= 62:
							w_direct = _('NE')
							w_directPix = 'NE'
						elif direct >= 63 and direct <= 117:
							w_direct = _('E')
							w_directPix = 'E'
						elif direct >= 118 and direct <= 152:
							w_direct = _('SE')
							w_directPix = 'SE'
						elif direct >= 153 and direct <= 207:
							w_direct = _('S')
							w_directPix = 'S'
						elif direct >= 208 and direct <= 242:
							w_direct = _('SW')
							w_directPix = 'SW'
						elif direct >= 243 and direct <= 297:
							w_direct = _('W')
							w_directPix = 'W'
						elif direct >= 298 and direct <= 332:
							w_direct = _('NW')
							w_directPix = 'NW'
						else:
							w_direct = _('N')
							w_directPix = 'N'
						weather_dict['wind_direction'] = w_direct
					except: pass
				elif line.find("<yweather:atmosphere") > -1:
					weather_dict['humidity'] = parse_line(line, 'humidity') + ' %'
					weather_dict['visibility'] = parse_line(line, 'visibility')
					weather_dict['pressure'] = parse_line(line, 'pressure')
					try:
						ttmp = float(weather_dict['pressure'])
						if units_dict['pressure'] == "hPa" and ttmp > 10000: 
							weather_dict['pressure'] = str(int(ttmp / 33.8638866667))
					except: pass
				elif line.find("<yweather:condition") > -1:
					try:
						weather_dict['date0'] = parse_line(line, 'date')
						weather_dict['text0'] = parse_line(line, 'text')
						weather_dict['picon0'] = nigttime(parse_line(line, 'code'))
						ttmp = parse_line(line, 'temp')
						weather_dict['temp0'] = temperature_fix(ttmp)
						setColor("0", int(ttmp), "", ENA_W)
					except: pass
				elif line.find("<yweather:forecast") > -1 and idx < 6:
					ena = -1
					if not config.plugins.setupGlass17.par92.value:
						try:
							w = (line.split('date')[1].split('"')[1]).split(' ')
							ena = (datetime.now()-datetime.strptime("%s-%s-%s-23-59" % (w[2],dd.get(w[1]),w[0]),"%Y-%m-%d-%H-%M")).days
						except: pass
					if ena < 0:
						try:
							weather_dict['date%s' % idx] = "%s\n%s" % (parse_line(line, 'day'), parse_line(line, 'date'))
							weather_dict['text%s' % idx] = parse_line(line, 'text')
							weather_dict['picon%s' % idx] = nigttime(parse_line(line, 'code'))
							ttmp = parse_line(line, 'high')
							weather_dict['temp%s' % idx] = temperature_fix(ttmp)
							setColor(idx, int(ttmp), "", ENA_W)
							ttmp = parse_line(line, 'low')
							weather_dict['templow%s' % idx] = temperature_fix(ttmp)
							setColor(idx, int(ttmp), 'low', ENA_C)
							idx += 1
						except: pass
			del dd
		if weather_dict['date0'] != UNKNOWN_STATE:
			try:
				if self.TITLE_S:
					weather_dict['temp0'] += ({False:'C', True:'F'}[self.units == 'f'])
				weather_dict['city'] = config.plugins.setupGlass17.par13.getText()
				if not ENA_MSN:
					for x in ['wind', 'visibility', 'pressure']:
						if weather_dict[x] != UNKNOWN_STATE:
							weather_dict[x] += " " + units_dict[x]
				if self.TITLE_S:
					a = weather_dict['country'] + "\n" + weather_dict['wind'] + "\n" + weather_dict['wind_direction'] + "\n" + weather_dict['humidity'] + "\n" + ({False:weather_dict['visibility'], True:weather_dict['lat']+", "+weather_dict['long']}[ENA_MSN]) + "\n" + ({False:weather_dict['pressure'], True:weather_dict['feelslike']}[ENA_MSN])
				else:
					a = ({False:weather_dict['city'] + "\n" + weather_dict['country'] + "\n", True:""}[self.LIGHT]) + weather_dict['wind'] + "\n" + weather_dict['wind_direction'] + "\n" + weather_dict['humidity'] + "\n" + ({False:weather_dict['visibility'], True:weather_dict['lat']+", "+weather_dict['long']}[ENA_MSN]) + "\n" + ({False:weather_dict['pressure'], True:weather_dict['feelslike']}[ENA_MSN])+({False:"", True:"\n" + weather_dict['sunrise'] + "\n" + weather_dict['sunset'] + "\n" + self.timeUpdate}[self.LIGHT])
				self['Weather_values'].setText(a)		
				self.setWindowTitle(({False:"", True:weather_dict['city']+", "}[self.TITLE_S])+weather_dict['date0'])
				if not self.LIGHT:
					path = config.plugins.setupGlass17.par39.value + "/weatherIcons/" + str(config.plugins.setupGlass17.par72.value) + "/" + w_directPix + ".png"
					if not os.path.isfile(path):
						path = NO_WIND_PICON
					self['Weather_wind'].instance.setPixmapFromFile(path)
					self['Weather_sunrise'].setText(weather_dict['sunrise'])
				self['Weather_sunset'].setText(({False:weather_dict['sunset'], True:weather_dict['city']}[self.LIGHT]))
				if ENA_ANIM:
					if self.animTimer.isActive():
						self.animTimer.stop()
					self.slide = {}
					self.pics = {}
				for x in range(0,6):
					if ENA_ANIM:
						f = None
						try:
							path = config.plugins.setupGlass17.par39.value + "/animIconWeather/" + weather_dict['picon%s' % x]
							f = len(os.listdir(path))
						except: pass
						self.slide[x] = 0
						self.pics[x] = []
						if f:
							for i in range(0,f):
								self.pics[x].append(LoadPixmap(path+"/"+str(i)+".png"))					
						else:
							self['Weather_picon%s' % x].instance.setPixmapFromFile(NO_WEATHER_PICON)
					else:
						path = config.plugins.setupGlass17.par39.value + "/weatherIcons/" + str(config.plugins.setupGlass17.par72.value) + "/" + weather_dict['picon%s' % x] + ".png"
						if not os.path.isfile(path):
							path = NO_WEATHER_PICON
						self['Weather_picon%s' % x].instance.setPixmapFromFile(path)
					self['Weather_Temperature%s' % x].setText(weather_dict['temp%s' % x])
					self['Weather_state%s' % x].setText(weather_dict['text%s' % x])
					if x != 0:
						self['Weather_Date%s' % x].setText(weather_dict['date%s' % x])
						self['Weather_Temperaturelow%s' % x].setText(weather_dict['templow%s' % x])
			except: pass       	  		
			if ENA_ANIM:
				self.animTimer.start(200)
		else:
			self.resetWeather_values(_('Error') + ": " + _("Mishmash in the data"))
		self.enaNC = True

	def resetWeather_values(self, d="", ee=True):  		
		try:
			if ENA_ANIM:
				if self.animTimer.isActive():
					self.animTimer.stop()
			self.setTitle(({False:_('Weather'), True:d}[d != ""]))
			self['Weather_values'].setText(self.RESET_VALUES)		
			self['Weather_wind'].instance.setPixmapFromFile(NO_WIND_PICON)
			self['Weather_sunrise'].setText(UNKNOWN_STATE)
			self['Weather_sunset'].setText(UNKNOWN_STATE)
			for x in range(0,6):
				self['Weather_picon%s' % x].instance.setPixmapFromFile(NO_WEATHER_PICON)
				self['Weather_Temperature%s' % x].setText(UNKNOWN_STATE_TEMP)		
				self['Weather_Temperature%s' % x].color4()
				self['Weather_state%s' % x].setText(UNKNOWN_STATE)
				if x != 0:
					self['Weather_Date%s' % x].setText(UNKNOWN_STATE)
					self['Weather_Temperaturelow%s' % x].setText(UNKNOWN_STATE_TEMP)		
					self['Weather_Temperaturelow%s' % x].color4()
			self.enaNC = True
			if ee and config.plugins.setupGlass17.par91.value != "0":
				tt = _("Attempt") + ": " + str(self.att)
				if d != "": 
					tt += ", " + d
				self.setTitle(tt)
				self.att += 1
				if self.weaTimer.isActive():
					self.weaTimer.stop()
				self.weaTimer.startLongTimer(int(config.plugins.setupGlass17.par91.value))    
		except: pass
                   			
	def setWindowTitle(self, txt):
		if not self.TITLE_S:
			if self.LIGHT:
				txt = txt.replace(self.timeUpdate, "") + ' (%s min)' % self.remainingTime			
			else:
				txt += ', ' + _('time to reconnect')+': %s min' % self.remainingTime
			txt += ', ('+unichr(176).encode("latin-1")+'%s)' % ({False:'C', True:'F'}[self.units == 'f'])
		self.setTitle(txt)
		
	def __runAnim(self):
		self.animTimer.stop()
		try:
			for x in range(0,len(self.slide)):
				a = len(self.pics[x])
				if a != 0:
					if self.slide[x] == a:
						self.slide[x] = 0
					self['Weather_picon%s' % x].instance.setPixmap(self.pics[x][self.slide[x]])	
					self.slide[x] += 1
		except: pass
		a = 50
		try:
			a = config.plugins.setupGlass17.par158.value
		except: pass
		self.animTimer.start(a)
    	
