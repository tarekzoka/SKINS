'''
Created on 10.10.2012
@author: duri, edited by shamann
@summary: optional cfg
@copyright: only the owner permission 
@license: from 6.0 to public version as a part of HDG 

@version: 6.0
@change: join with HDG
@todo:  
@status: pre-final
'''


#path to file oscam.provid
OSCAMPROVIDER = "/etc/tuxbox/config/oscam.provid"

#length of string for provider, 0 - unlimited length of string
PROVIDERLENGHT = 33

#autoupdate of view ecm info
ECMUPDATE = True #False - stop update of ecm view , True - run update of ecm view
ECMUPDATETIME = 6000 #time in miliseconds for autoupdate
