#######################################################################
#
#    Renderer for Enigma2
#    Coded by shamann (c)2017
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License
#    as published by the Free Software Foundation; either version 2
#    of the License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#    
#######################################################################

from Renderer import Renderer
from enigma import eLabel
from Components.VariableText import VariableText
from enigma import eServiceCenter, iServiceInformation, eDVBFrontendParametersSatellite, eDVBFrontendParametersCable, eDVBFrontendParametersTerrestrial
from xml.etree.cElementTree import parse
from Components.config import config
try:
	from Plugins.Extensions.setupGlass17.txt import NO_TP
except: NO_TP = 'TP info is not detected'
ENA_TT = False
try:
	from enigma import iDVBFrontend
	ENA_TT = True
except: pass

class g17ShowTP(VariableText, Renderer):

	def __init__(self):
		Renderer.__init__(self)
		VariableText.__init__(self)
		self.ena = True
		try:
			self.ena = config.plugins.setupGlass17.par48.value
		except: pass
		if not self.ena:
			try:
				self.allSat = {}
				satellites = parse(config.plugins.setupGlass17.par141.value+"satellites.xml").getroot()
				if satellites is not None:
					for x in satellites.findall("sat"):
						name = x.get("name") or None
						position = x.get("position") or None
						if name is not None and position is not None:
							position = "%s.%s" % (position[:-1], position[-1:])
							if position.startswith("-"):
								position = "%sW" % position[1:]
							else:
								position = "%sE" % position
							if position.startswith("."):
								position = "0%s" % position
							self.allSat[position] = str(name.encode("utf-8"))
			except: pass
	GUI_WIDGET = eLabel

	def connect(self, source):
		Renderer.connect(self, source)
		self.changed((self.CHANGED_DEFAULT,))
		
	def changed(self, what):
		def convCH(what):
			fqT = ""
			try:
				fqT = int(((int(what) - 474) / 8) + 21)
				if fqT < 21 or fqT > 69:
					fqT = ""
				else:
					fqT = "MHz (CH %d) " % fqT						
			except: pass
			return fqT
		if self.instance:
			if what[0] == self.CHANGED_CLEAR:
				self.text = NO_TP
			else:
				serviceref = self.source.service
				info = eServiceCenter.getInstance().info(serviceref)
				if info and serviceref:
					sname = info.getInfoObject(serviceref, iServiceInformation.sTransponderData)
					fq = pol = fec = sr = orb = ""
					try:
						orb = str(sname.get("tuner_type","None"))
						if ENA_TT and orb != "None":
							try:
								orb = {iDVBFrontend.feSatellite : "0",iDVBFrontend.feCable : "1",iDVBFrontend.feTerrestrial : "2",iDVBFrontend.feSatellite2 : "0",iDVBFrontend.feTerrestrial2 : "2"}[int(orb)]
							except: 
								try:
									orb = {iDVBFrontend.feSatellite : "0",iDVBFrontend.feCable : "1",iDVBFrontend.feTerrestrial : "2"}[int(orb)]
								except: pass
						if orb == "1":
							orb = "DVB-C"
						elif orb == "2":
							orb = "DVB-T"
						if sname.has_key("frequency"):
							fq = int(round(1.0 * int(sname["frequency"])/1000))
							if (fq > 9999 and fq < 99999 and orb == "DVB-C") or fq > 99999:
								fq = int(round(1.0 * fq / 1000))
							fq = str(fq)
							if orb == "DVB-T":
								fq += convCH(fq)							
								try:
									orb = {
												eDVBFrontendParametersTerrestrial.System_DVB_T : "DVB-T",
												eDVBFrontendParametersTerrestrial.System_DVB_T2 : "DVB-T2"
											}[sname.get("system", eDVBFrontendParametersTerrestrial.System_DVB_T)]
								except: pass
						if sname.has_key("polarization"):
							try:
								pol = {
									eDVBFrontendParametersSatellite.Polarisation_Horizontal : "H  ",
									eDVBFrontendParametersSatellite.Polarisation_Vertical : "V  ",
									eDVBFrontendParametersSatellite.Polarisation_CircularLeft : "CL  ",
									eDVBFrontendParametersSatellite.Polarisation_CircularRight : "CR  "}[sname["polarization"]]
							except:
								pol = "N/A  "
						if sname.has_key("fec_inner"):
							try:
								fec = {
									eDVBFrontendParametersSatellite.FEC_None : _("None  "),
									eDVBFrontendParametersSatellite.FEC_Auto : _("Auto  "),
									eDVBFrontendParametersSatellite.FEC_1_2 : "1/2  ",
									eDVBFrontendParametersSatellite.FEC_2_3 : "2/3  ",
									eDVBFrontendParametersSatellite.FEC_3_4 : "3/4  ",
									eDVBFrontendParametersSatellite.FEC_5_6 : "5/6  ",
									eDVBFrontendParametersSatellite.FEC_7_8 : "7/8  ",
									eDVBFrontendParametersSatellite.FEC_3_5 : "3/5  ",
									eDVBFrontendParametersSatellite.FEC_4_5 : "4/5  ",
									eDVBFrontendParametersSatellite.FEC_8_9 : "8/9  ",
									eDVBFrontendParametersSatellite.FEC_9_10 : "9/10  "}[sname["fec_inner"]]
							except:
								fec = "N/A  "
							if fec == "N/A  ":
								try:
									fec = {
										eDVBFrontendParametersCable.FEC_None : _("None  "),
										eDVBFrontendParametersCable.FEC_Auto : _("Auto  "),
										eDVBFrontendParametersCable.FEC_1_2 : "1/2  ",
										eDVBFrontendParametersCable.FEC_2_3 : "2/3  ",
										eDVBFrontendParametersCable.FEC_3_4 : "3/4  ",
										eDVBFrontendParametersCable.FEC_5_6 : "5/6  ",
										eDVBFrontendParametersCable.FEC_7_8 : "7/8  ",
										eDVBFrontendParametersCable.FEC_8_9 : "8/9  ",}[sname["fec_inner"]]
								except:
									fec = "N/A  "
						if sname.has_key("code_rate_lp"):
							try:
								fec = {
									eDVBFrontendParametersTerrestrial.FEC_Auto : _("Auto  "),
									eDVBFrontendParametersTerrestrial.FEC_1_2 : "1/2  ",
									eDVBFrontendParametersTerrestrial.FEC_2_3 : "2/3  ",
									eDVBFrontendParametersTerrestrial.FEC_3_4 : "3/4  ",
									eDVBFrontendParametersTerrestrial.FEC_5_6 : "5/6  ",
									eDVBFrontendParametersTerrestrial.FEC_7_8 : "7/8  ",}[sname["code_rate_lp"]]
							except: pass
						if sname.has_key("bandwidth"):
							try:
								pol = {
									eDVBFrontendParametersTerrestrial.Bandwidth_8MHz : "8MHz  ",
									eDVBFrontendParametersTerrestrial.Bandwidth_7MHz : "7MHz  ",
									eDVBFrontendParametersTerrestrial.Bandwidth_6MHz : "6MHz  ",}[sname["bandwidth"]]
							except: pass
						if sname.has_key("symbol_rate"):
							sr = "%s  " % (int(sname["symbol_rate"])/1000)
						if sname.has_key("orbital_position"):	
							numSat = sname["orbital_position"]
							if numSat > 1800:
								idx = str((float(3600 - numSat))/10.0) + "W"
							else:
								idx = str((float(numSat))/10.0) + "E"
							if idx != "0.2E":
								if not self.ena:
									if self.allSat.has_key(idx):
										orb = self.allSat.get(idx)
									else:
										orb = "Sat on position: %s" % idx
								else:
									orb = idx
							else:
								fq = str(int(fq)-1000)
								fq += convCH(fq)
								orb = "DVB-T"
								pol = sr = ""
					except:
						pass
					if fq != "":
						pls = ''
						if self.ena and (sname.has_key("pls_mode") or sname.has_key("is_id") or sname.has_key("pls_code")):
							i = str(sname.get('is_id', 0))
							c = str(sname.get('pls_code', 0))
							m = str(sname.get('pls_mode', None))
							if not(m == 'None' or i == '-1' or i == '255' or i == '0' and c == '1'):
								if m.isdigit():
									try:
										m = {
											eDVBFrontendParametersSatellite.PLS_Root : "Root",
											eDVBFrontendParametersSatellite.PLS_Gold : "Gold",
											eDVBFrontendParametersSatellite.PLS_Combo : "Combo",
											eDVBFrontendParametersSatellite.PLS_Unknown : "U"}[sname["pls_mode"]]
									except: pass
								pls = ' MS:%s %s %s' % (i,c.replace('262143', ''),m.replace('U', ''))
						try:
							orb = orb.replace("E)","\xc2\xb0E)").replace("W)","\xc2\xb0W)")
						except: pass
						self.text = fq + " " + pol + fec + sr + orb + pls
					else:
						self.text = NO_TP
