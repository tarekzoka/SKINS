#######################################################################
#
#    Converter for Enigma2
#    Coded by shamann (c)2017
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License
#    as published by the Free Software Foundation; either version 2
#    of the License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#    
#######################################################################

from Renderer import Renderer
from enigma import ePixmap
from Tools.Directories import fileExists, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, resolveFilename
from enigma import eServiceCenter, iServiceInformation, eDVBFrontendParametersSatellite, eDVBFrontendParametersCable, eDVBFrontendParametersTerrestrial
from Components.config import config
ENA_TT = False
try:
	from enigma import iDVBFrontend
	ENA_TT = True
except: pass

class g17satTV(Renderer):

	def __init__(self):
		Renderer.__init__(self)
		self.satCache = { }
		self.pngname = ""
		self.__isInst = True
	GUI_WIDGET = ePixmap

	def changed(self, what):
		if self.instance:
			if self.__isInst:
				self.instance.setScale(1)
				self.__isInst = False
				try:
					if config.plugins.setupGlass17.par161.value and config.plugins.setupGlass17.par166.value != "None":
						self.instance.setShowHideAnimation(config.plugins.setupGlass17.par166.value)
				except: pass
			pngname = name = ""
			if what[0] != self.CHANGED_CLEAR:
				serviceref = self.source.service
				info = eServiceCenter.getInstance().info(serviceref)
				if info and serviceref:
					try:
						sname = info.getInfoObject(serviceref, iServiceInformation.sTransponderData)
						orb = str(sname.get("tuner_type","None"))
						if ENA_TT and orb != "None":
							try:
								orb = {iDVBFrontend.feSatellite : "0",iDVBFrontend.feCable : "1",iDVBFrontend.feTerrestrial : "2",iDVBFrontend.feSatellite2 : "0",iDVBFrontend.feTerrestrial2 : "2"}[int(orb)]
							except: 
								try:
									orb = {iDVBFrontend.feSatellite : "0",iDVBFrontend.feCable : "1",iDVBFrontend.feTerrestrial : "2"}[int(orb)]
								except: pass
						if orb in ("1","DVB-C"):
							name = "picon_cable"
						elif orb in ("2","DVB-T"):
							name = "picon_trs"
						if name == "":
							if sname.has_key("orbital_position"):	
								orb = sname["orbital_position"]
								if orb > 1800:
									orb = str(3600 - orb) + "W"
								else:
									orb = str(orb) + "E"
								if orb == "2E":
									name = "picon_trs"
								else:
									name = orb
						if name != "":
							pngname = self.satCache.get(name, "")
							if pngname == "":
								pngname = self.findSat(name)
								if pngname != "":
									self.satCache[name] = pngname
					except: pass
				if pngname == "":
					pngname = self.satCache.get("picon_default", "")
					if pngname == "":
						pngname = self.findSat("picon_default")
						if pngname == "":
							tmp = resolveFilename(SCOPE_CURRENT_SKIN, "picon_default.png")
							if fileExists(tmp):
								pngname = tmp
							else:
								pngname = resolveFilename(SCOPE_SKIN_IMAGE, "skin_default/picon_default.png")
						self.satCache["default"] = pngname
				if self.pngname != pngname:
					self.pngname = pngname
					self.instance.setPixmapFromFile(self.pngname)            		

	def findSat(self, serviceName):
		try:
			pngname = config.plugins.setupGlass17.par39.value + "/piconSat/" + serviceName + ".png"
			if fileExists(pngname):
				return pngname
		except: pass
		return ""
