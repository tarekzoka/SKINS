# Embedded file name: /usr/lib/enigma2/python/Components/Renderer/FixedLabel.py
from Renderer import Renderer
from enigma import eLabel

class BetaLabel(Renderer):
    GUI_WIDGET = eLabel