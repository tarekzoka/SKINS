#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
# -*- coding: utf-8 -*-
#######################################################################
from Components.Converter.Converter import Converter
from Components.config import config, ConfigText, ConfigNumber, ConfigDateTime
from Components.Element import cached
from Components.Converter.Poll import Poll



class TeamNitroWeather(Poll, Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type
		Poll.__init__(self)
		self.poll_interval = 60000
		self.poll_enabled = True

	@cached
	def getText(self):
		try:
			if config.plugins.TeamNitroWeather.tempplus.value:
				config.plugins.TeamNitroWeather.tempplus.setValue(False) # option disabled -> WeatherSettingsView
				config.plugins.TeamNitroWeather.save()
			if self.type == "currentLocation":
				return config.plugins.TeamNitroWeather.currentLocation.value
			elif self.type == "currentWeatherTemp":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.currentWeatherTemp.value.startswith("-") or config.plugins.TeamNitroWeather.currentWeatherTemp.value.startswith("0"):
						return config.plugins.TeamNitroWeather.currentWeatherTemp.value
					return "+" + config.plugins.TeamNitroWeather.currentWeatherTemp.value
				return config.plugins.TeamNitroWeather.currentWeatherTemp.value
			elif self.type == "currentWeatherTempgetCF":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.currentWeatherTemp.value.startswith("-") or config.plugins.TeamNitroWeather.currentWeatherTemp.value.startswith("0"):
						return config.plugins.TeamNitroWeather.currentWeatherTemp.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.currentWeatherTemp.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.currentWeatherTemp.value + " " + self.getCF()
			elif self.type == "currentWeatherText":
				return config.plugins.TeamNitroWeather.currentWeatherText.value
			elif self.type == "currentWeatherTempheigh_low":
				if config.plugins.TeamNitroWeather.tempplus.value:
					tempmax = ""
					templov = ""
					if config.plugins.TeamNitroWeather.forecastTodayTempMax.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTodayTempMax.value.startswith("0"):
						tempmax = config.plugins.TeamNitroWeather.forecastTodayTempMax.value
					else:
						tempmax = "+" + config.plugins.TeamNitroWeather.forecastTodayTempMax.value
					if config.plugins.TeamNitroWeather.forecastTodayTempMin.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTodayTempMin.value.startswith("0"):
						templov = config.plugins.TeamNitroWeather.forecastTodayTempMin.value
					else:
						templov = "+" + config.plugins.TeamNitroWeather.forecastTodayTempMin.value
					return tempmax + " " + self.getCF() + " - " + templov + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTodayTempMax.value + " " + self.getCF() + " - " + config.plugins.TeamNitroWeather.forecastTodayTempMin.value + " " + self.getCF()
			elif self.type == "currentWeatherCode":
				return config.plugins.TeamNitroWeather.currentWeatherCode.value
			elif self.type == "currenthumidity":
				return config.plugins.TeamNitroWeather.currentWeatherhumidity.value + " %"
			elif self.type == "currentwinddisplay":
				return config.plugins.TeamNitroWeather.currentWeatherwinddisplay.value
			elif self.type == "currentwindspeed":
				return config.plugins.TeamNitroWeather.currentWeatherwindspeed.value
			elif self.type == "currentshortday":
				return config.plugins.TeamNitroWeather.currentWeathershortday.value
			elif self.type == "currenthdate":
				return config.plugins.TeamNitroWeather.currentWeatherdate.value
			elif self.type == "currenthday":
				return config.plugins.TeamNitroWeather.currentWeatherday.value
			elif self.type == "currentfeelslike":
				return config.plugins.TeamNitroWeather.currentWeatherfeelslike.value + " " + self.getCF()
			elif self.type == "currentobservationtime":
				return config.plugins.TeamNitroWeather.currentWeatherobservationtime.value
			elif self.type == "forecastTodayCode":
				return config.plugins.TeamNitroWeather.forecastTodayCode.value
			elif self.type == "forecastTodaydate":
				return config.plugins.TeamNitroWeather.forecastTodaydate.value
			elif self.type == "forecastTodayday":
				return config.plugins.TeamNitroWeather.forecastTodayday.value
			elif self.type == "forecastTodayTempMin":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.forecastTodayTempMin.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTodayTempMin.value.startswith("0"):
						return config.plugins.TeamNitroWeather.forecastTodayTempMin.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.forecastTodayTempMin.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTodayTempMin.value + " " + self.getCF()
			elif self.type == "forecastTodayTempMax":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.forecastTodayTempMax.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTodayTempMax.value.startswith("0"):
						return config.plugins.TeamNitroWeather.forecastTodayTempMax.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.forecastTodayTempMax.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTodayTempMax.value + " " + self.getCF()
			elif self.type == "forecastTodayText":
				return config.plugins.TeamNitroWeather.forecastTodayText.value




			elif self.type == "forecastTomorrowCode":
				return config.plugins.TeamNitroWeather.forecastTomorrowCode.value
			elif self.type == "forecastTomorrowdate":
				return config.plugins.TeamNitroWeather.forecastTomorrowdate.value
			elif self.type == "forecastTomorrowday":
				return config.plugins.TeamNitroWeather.forecastTomorrowday.value
			elif self.type == "forecastTomorrowshortday":
				return config.plugins.TeamNitroWeather.forecastTomorrowshortday.value
			elif self.type == "forecastTomorrowTempMin":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.forecastTomorrowTempMin.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTomorrowTempMin.value.startswith("0"):
						return config.plugins.TeamNitroWeather.forecastTomorrowTempMin.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.forecastTomorrowTempMin.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTomorrowTempMin.value + " " + self.getCF()
			elif self.type == "forecastTomorrowTempMax":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.forecastTomorrowTempMax.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTomorrowTempMax.value.startswith("0"):
						return config.plugins.TeamNitroWeather.forecastTomorrowTempMax.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.forecastTomorrowTempMax.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTomorrowTempMax.value + " " + self.getCF()
			elif self.type == "forecastTomorrowText":
				return config.plugins.TeamNitroWeather.forecastTomorrowText.value
			elif self.type == "forecastTomorrowCode2":
				return config.plugins.TeamNitroWeather.forecastTomorrowCode2.value
			elif self.type == "forecastTomorrowTempMin2":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.forecastTomorrowTempMin2.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTomorrowTempMin2.value.startswith("0"):
						return config.plugins.TeamNitroWeather.forecastTomorrowTempMin2.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.forecastTomorrowTempMin2.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTomorrowTempMin2.value + " " + self.getCF()
			elif self.type == "forecastTomorrowTempMax2":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.forecastTomorrowTempMax2.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTomorrowTempMax2.value.startswith("0"):
						return config.plugins.TeamNitroWeather.forecastTomorrowTempMax2.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.forecastTomorrowTempMax2.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTomorrowTempMax2.value + " " + self.getCF()
			elif self.type == "forecastTomorrowText2":
				return config.plugins.TeamNitroWeather.forecastTomorrowText2.value
			elif self.type == "forecastTomorrowdate2":
				return config.plugins.TeamNitroWeather.forecastTomorrowdate2.value
			elif self.type == "forecastTomorrowday2":
				return config.plugins.TeamNitroWeather.forecastTomorrowday2.value
			elif self.type == "forecastTomorrowshortday2":
				return config.plugins.TeamNitroWeather.forecastTomorrowshortday2.value
			elif self.type == "forecastTomorrowCode3":
				return config.plugins.TeamNitroWeather.forecastTomorrowCode3.value
			elif self.type == "forecastTomorrowTempMin3":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.forecastTomorrowTempMin3.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTomorrowTempMin3.value.startswith("0"):
						return config.plugins.TeamNitroWeather.forecastTomorrowTempMin3.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.forecastTomorrowTempMin3.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTomorrowTempMin3.value + " " + self.getCF()
			elif self.type == "forecastTomorrowTempMax3":
				if config.plugins.TeamNitroWeather.tempplus.value:
					if config.plugins.TeamNitroWeather.forecastTomorrowTempMax3.value.startswith("-") or config.plugins.TeamNitroWeather.forecastTomorrowTempMax3.value.startswith("0"):
						return config.plugins.TeamNitroWeather.forecastTomorrowTempMax3.value + " " + self.getCF()
					return "+" + config.plugins.TeamNitroWeather.forecastTomorrowTempMax3.value + " " + self.getCF()
				return config.plugins.TeamNitroWeather.forecastTomorrowTempMax3.value + " " + self.getCF()
			elif self.type == "forecastTomorrowText3":
				return config.plugins.TeamNitroWeather.forecastTomorrowText3.value
			elif self.type == "forecastTomorrowdate3":
				return config.plugins.TeamNitroWeather.forecastTomorrowdate3.value
			elif self.type == "forecastTomorrowday3":
				return config.plugins.TeamNitroWeather.forecastTomorrowday3.value
			elif self.type == "forecastTomorrowshortday3":
				return config.plugins.TeamNitroWeather.forecastTomorrowshortday3.value
			elif self.type == "title":
				return self.getCF() + " | " + config.plugins.TeamNitroWeather.currentLocation.value
			elif self.type == "CF":
				return self.getCF()
			else:
				return ""
		except:
			return ""

	@cached
	def getValue(self):
		if self.type == "currentDataValid":
			try:
				return config.plugins.TeamNitroWeather.currentWeatherDataValid.value
			except ValueError:
				return 0
		return -1

	def getCF(self):
		if config.plugins.TeamNitroWeather.tempUnit.value == "Fahrenheit":
			return "Fahrenheit"
		else:
			return "Celsius"

	value = property(getValue)
	text = property(getText)
