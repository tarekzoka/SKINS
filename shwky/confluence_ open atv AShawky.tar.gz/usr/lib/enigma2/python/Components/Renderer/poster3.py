# -*- coding: utf-8 -*-
# by digiteng...07.2021
# russian and py3 support by sunriser...
# 07.2021 start edit lululla
# <widget source="session.Event_Now" render="ZPoster" position="1620,505" size="300,438" alphatest="blend" zPosition="9" />
# <widget source="session.Event_Next" render="ZPoster" position="1620,505" size="300,438" alphatest="blend" zPosition="9" />
try:
    from Components.Renderer.Renderer import Renderer
except:
    from Renderer import Renderer
from enigma import ePixmap, ePicLoad, eTimer
import re
import glob
import six
from six.moves.urllib.request import urlopen
from six.moves.urllib.parse import quote
import json, os, socket, shutil
from Components.AVSwitch import AVSwitch
from Components.config import config
from Tools.Directories import fileExists
global cur_skin, my_cur_skin, apikey
my_cur_skin = False
apikey = "3c3efcf47c3577558812bb9d64019d65"
cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
print('skin name /usr/share/enigma2/', cur_skin)
folder_path = "/tmp/poster3/"
if not os.path.exists(folder_path):
    os.makedirs(folder_path)
try:
    folder_size=sum([sum(map(lambda fname: os.path.getsize(os.path.join(folder_path, fname)), files)) for folder_path, folders, files in os.walk(folder_path)])
    poster3 = "%0.f" % (folder_size/(1024*1024.0))
    if poster3 >= "5":
        shutil.rmtree(folder_path)
except:
    pass

try:
    from Components.config import config
    language = config.osd.language.value
    language = language[:-3]
except:
	language = 'en'
	pass
print('language: ', language)
try:
    if my_cur_skin == False:
        myz_skin = "/usr/share/enigma2/%s/apikey" %cur_skin
        print('skinz namez', myz_skin)
        if os.path.exists(myz_skin):
            with open(myz_skin, "r") as f:
                apikey = f.read()
                my_cur_skin = True
except:
    my_cur_skin = False
    apikey = "3c3efcf47c3577558812bb9d64019d65"
print('my apikey in use: ', apikey)

REGEX = re.compile(
		r'([\(\[]).*?([\)\]])|'
		r'(: odc.\d+)|'
		r'(\d+: odc.\d+)|'
		r'(\d+ odc.\d+)|(:)|'
		r'( -(.*?).*)|(,)|'
		r'!|'
		r'/.*|'
		r'\|\s[0-9]+\+|'
		r'[0-9]+\+|'
		r'\s\d{4}\Z|'
		r'([\(\[\|].*?[\)\]\|])|'
		r'(\"|\"\.|\"\,|\.)\s.+|'
		r'\"|:|'
		r'Премьера\.\s|'
		r'(х|Х|м|М|т|Т|д|Д)/ф\s|'
		r'(х|Х|м|М|т|Т|д|Д)/с\s|'
		r'\s(с|С)(езон|ерия|-н|-я)\s.+|'
		r'\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|'
		r'\.\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|'
		r'\s(ч|ч\.|с\.|с)\s\d{1,3}.+|'
		r'\d{1,3}(-я|-й|\sс-н).+|', re.DOTALL)



class poster3(Renderer):
    def __init__(self):
        Renderer.__init__(self)
        self.timerpost = eTimer()
        # self.timer20 = eTimer()        
        self.intCheck()

    def intCheck(self):
        try:
            socket.setdefaulttimeout(0.5)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
            return True
        except:
            return False
    # def intCheck(self):
        # from six.moves.urllib.error import HTTPError, URLError
        # try:
            # response = urlopen("http://google.com", None, 5)
            # response.close()
        # except urllib2.HTTPError:
            # return False
        # except urllib2.URLError:
            # return False
        # except socket.timeout:
            # return False
        # else:
            # return True
    GUI_WIDGET = ePixmap
    def changed(self, what):
        if not self.instance:
            return
        # if self.timer20:    
            # self.timer20.stop()  
        if self.timerpost:
            self.timerpost.stop()
            
        if what[0] == self.CHANGED_CLEAR:
            self.instance.hide()
        if what[0] != self.CHANGED_CLEAR:
            self.instance.hide()        
            self.delay()
            # self.timer20.stop()            
            # try:
                # self.timer20.callback.append(self.delay)
            # except:
                # self.timer20_conn = self.timer20.timeout.connect(self.delay)
            # self.timer20.start(500, True)                  

    def delay(self):
        self.pstrNm = ''
        self.evntNm = ''
        self.downloading = False
        self.event = self.source.event
        if self.event:
            evntNm = REGEX.sub('', self.event.getEventName()).strip()
            evntNm = evntNm.replace('\xc2\x86', '').replace('\xc2\x87', '')
            evntNm = evntNm.replace('FILM ', '').replace('FILM - ', '').replace('film - ', '').replace('TELEFILM ', '').replace('TELEFILM - ', '').replace('telefilm - ', '')
            self.evntNm = evntNm
            self.pstrNm = "{}{}.jpg".format(folder_path,quote(self.evntNm))
            if os.path.exists(self.pstrNm):
                self.showPoster()
            else:

                self.info()
                # self.instance.hide()
                # try:
                    # self.timerpost.callback.append(self.info)
                # except:
                    # self.timerpost_conn = self.timerpost.timeout.connect(self.info)
                # self.timerpost.start(100, False)
        #test su cover che non va via lasciando il posto a nocover
        else:
            self.instance.hide()
            self.timerpost.stop()
            
    def showPoster(self):
        if os.path.exists(self.pstrNm):
            size = self.instance.size()
            self.picload = ePicLoad()
            sc = AVSwitch().getFramebufferScale()
            if self.picload:
                self.picload.setPara([size.width(), size.height(), sc[0], sc[1], False, 1, '#00000000'])
                if os.path.exists('/var/lib/dpkg/status'):
                    self.picload.startDecode(self.pstrNm, False)
                else:
                    self.picload.startDecode(self.pstrNm, 0, 0, False)
            ptr = self.picload.getData()
            if ptr != None:
                self.instance.setPixmap(ptr)
                self.instance.show()
            else:
                self.instance.hide()

    def info(self):
        if self.downloading:
            return
        self.downloading = True
        # try:
            # url = 'http://api.themoviedb.org/3/search/tv?api_key={}&query={}'.format(apikey,quote(self.evntNm))
            # # if six.PY3:
                # # url = url.encode()
            # url2 = urlopen(url).read().decode('utf-8')
            # jurl = json.loads(url2)
            # if 'results' in jurl:
                # if 'id' in jurl['results'][0]:
                    # ids = jurl['results'][0]['id']
                    # url_2 = 'http://api.themoviedb.org/3/tv/' + str(ids) + '?api_key={}&language={}'.format(apikey,str(language))
                    # # if six.PY3:
                        # # url_2 = url_2.encode()
                    # url_3 = urlopen(url_2).read().decode('utf-8')
                    # data2 = json.loads(url_3)
                    # poster = data2['poster_path']
                    # if poster:
                        # self.url_poster = "http://image.tmdb.org/t/p/w185{}".format(poster) #w185 risoluzione poster
                        # self.timerpost.stop()                       
                        # self.savePoster()
            # self.timerpost.stop()
        # except:
        try:
            url = 'http://api.themoviedb.org/3/search/movie?api_key={}&query={}'.format(apikey,quote(self.evntNm))
            # if six.PY3:
                # url = url.encode()
            url2 = urlopen(url).read().decode('utf-8')
            jurl = json.loads(url2)
            if 'results' in jurl:
                if 'id' in jurl['results'][0]:
                    ids = jurl['results'][0]['id']
                    url_2 = 'http://api.themoviedb.org/3/movie/' + str(ids) + '?api_key={}&language={}'.format(apikey,str(language))
                    # if six.PY3:
                        # url_2 = url_2.encode()
                    url_3 = urlopen(url_2).read().decode('utf-8')
                    data2 = json.loads(url_3)
                    poster = data2['poster_path']
                    if poster:
                        self.url_poster = "http://image.tmdb.org/t/p/w185{}".format(str(poster))
                        self.timerpost.stop()                     
                        self.savePoster()
            # self.timerpost.stop()
        except:
            # self.timerpost.stop()
            self.downloading = False
            pass

    def savePoster(self):
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        pic_image = urlopen(self.url_poster).read()
        try:
            with open(self.pstrNm, "wb") as f:
                f.write(pic_image)
            self.showPoster()
        except:
            pass
