# by digiteng...11.2020
# <widget render="NachtAnimWeath" path="/media/hdd/AnimatedWeatherPixmap/" position="75,215" size="128,128" source="session.MSNWeather" alphatest="blend" transparent="1" zPosition="9">
  # <convert type="MSNWeather">weathericon,current</convert>
# </widget>
from Renderer import Renderer
from enigma import ePixmap
import os
import threading
import time

class NachtAnimWeath(Renderer):
	def __init__(self):
		Renderer.__init__(self)
		
	def applySkin(self, desktop, screen):
		attribs = self.skinAttributes[:]
		for attrib, value in self.skinAttributes:
			if attrib == "path":
				self.path = value
		self.skinAttributes = attribs
		ret = Renderer.applySkin(self, desktop, screen)

	GUI_WIDGET = ePixmap
	def changed(self, what):
		if self.instance:
			st = ""
			if what[0] != self.CHANGED_CLEAR:
				try:
					st = self.source.iconfilename
					self.st = st.split("/")[-1].replace(".gif", "")
				except:
					pass
				threading.Thread(target=self.anim).start()

	def anim(self):
		list = os.listdir(self.path + self.st)
		list_size = len(list)
		lst = []
		for i in range(list_size):
			lst.append("/a{}.png".format(i))
		i = list_size
		while True:
			i -= 1
			time.sleep(0.1)
			self.instance.setPixmapFromFile(self.path + self.st + lst[i])
			self.instance.setScale(1)		
			if i == 0:
				i = list_size
				continue
