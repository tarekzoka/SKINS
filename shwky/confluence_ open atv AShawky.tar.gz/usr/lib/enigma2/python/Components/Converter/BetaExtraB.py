# -*- coding: utf-8 -*-
# Mod By bahaa (LinuXcode)  10-10-2022
from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Converter.Poll import Poll
# from enigma import eConsoleAppContainer
import os, re, socket

class BetaExtraB(Poll, Converter):
    IPLOCAL = 0

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        # self.container = eConsoleAppContainer()
        type = type.split(',')
        self.short_list = True
        self.list = []
        self.shortFormat = 'Short' in type

        if 'Iplocal' in type:
            self.type = self.IPLOCAL

        self.poll_enabled = True



    @cached
    def getText(self):
        if self.type == self.IPLOCAL: # mod By bahaa  
            try:               
                gw = os.popen("ip -4 route show default").read().split()
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect((gw[2], 0))
                ipaddr = s.getsockname()[0]
                return "%s" % ipaddr
            except:                                   
                ipaddr = "Not Connected"
                return "%s" % ipaddr
        return text
    text = property(getText)

    def changed(self, what):
        if what[0] == self.CHANGED_POLL:
            self.downstream_elements.changed(what)
