# -*- coding: utf-8 -*-
# Mod By bahaa (LinuXcode)  10-10-2022
from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Converter.Poll import Poll
from enigma import eConsoleAppContainer
import os,socket,re  

class BetaExtraC(Poll, Converter):
    # IPLOCAL = 0
    TEMPERATURE = 1
    UPTIME = 2


    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.container = eConsoleAppContainer()
        type = type.split(',')
        self.short_list = True
        self.list = []
        self.shortFormat = 'Short' in type
 
        if 'Iplocal' in type:
            self.type = self.IPLOCAL
        elif 'Temperature' in type:
            self.type = self.TEMPERATURE
        elif 'Uptime' in type:
            self.type = self.UPTIME

 

    @cached
    def getText(self):
        if self.type == self.TEMPERATURE:
            systemp = ""
            cputemp = ""
            try:
                if os.path.exists("/proc/stb/sensors/temp0/value"):
                    with open("/proc/stb/sensors/temp0/value") as stemp:
                        systemp = "%s°C" % stemp.readline().replace("\n", "")
                elif os.path.exists("/proc/stb/fp/temp_sensor"):
                    with open("/proc/stb/fp/temp_sensor") as stemp:
                        systemp = "%s°C" % stemp.readline().replace("\n", "")
                if os.path.exists("/proc/stb/fp/temp_sensor_avs"):
                    with open("/proc/stb/fp/temp_sensor_avs") as ctemp:
                        cputemp = "%s°C" % ctemp.readline().replace("\n", "")
                elif os.path.exists("/sys/devices/virtual/thermal/thermal_zone0/temp"):
                    with open("/sys/devices/virtual/thermal/thermal_zone0/temp") as ctemp:
                        cputemp = "%s°C" % ctemp.read()[:2].replace("\n", "")
                elif os.path.exists("/proc/hisi/msp/pm_cpu"):
                    for line in open("/proc/hisi/msp/pm_cpu").readlines():
                        line = [x.strip() for x in line.strip().split(":")]
                        if line[0] in ("Tsensor"):
                            ctemp = line[1].split("=")
                            ctemp = line[1].split(" ")
                            cputemp = "%s°C" % ctemp[2]
            except:
                pass
            if systemp == "" and cputemp == "":
                return "N/A"
            if systemp == "":
                return "CPU Temp:  %s" % cputemp
            if cputemp == "":
                return systemp
            return "%CPU Temp:  s" % (cputemp)
 

       
 

        if self.type == self.UPTIME:
            try:
                with open('/proc/uptime', 'r') as (up):
                    uptime_info = up.read().split()
            except:
                return 'Uptime: N/A'
                uptime_info = None

            if uptime_info is not None:        # mod By bahaa (LinuXcode) 
                total_seconds = float(uptime_info[0])
                MINUTE = 60
                HOUR = MINUTE * 60
                DAY = HOUR * 24
                days = str(int(total_seconds / DAY))
                hours = str(int(total_seconds % DAY / HOUR))
                minutes = str(int(total_seconds % HOUR / MINUTE))
                seconds = str(int(total_seconds % MINUTE))
                uptime = ''
                if seconds  >'0':
                    uptime = '%s Sec' % (seconds)
                if minutes >'0':
                    uptime = '%s Min  %s Sec' % (minutes, seconds)
                if hours >'0'  :
                    uptime = '%s Hrs %s Min %s Sec' % (hours, minutes, seconds)
                if days >'0'  :
                    uptime = '%s Days %s Hrs %s Min ' % (days, hours, minutes)
            return 'Uptime: %s' % uptime
        return text

    text = property(getText)

    def changed(self, what):
        if what[0] == self.CHANGED_POLL:
            self.downstream_elements.changed(what)
