# -*- coding: utf-8 -*-
import sys
PV=sys.version_info[0]

from enigma import ePixmap, ePicLoad, eTimer, eEPGCache, loadPNG
from Components.AVSwitch import AVSwitch
from Components.Pixmap import Pixmap
if PV == 2:
    from urllib2 import urlopen, quote
    from Renderer import Renderer
else:
    from urllib.request import urlopen
    from urllib.parse import quote
    from Components.Renderer.Renderer import Renderer


import re
import os
import traceback
import socket
import csv
from datetime import datetime, timedelta

DEBUG=True
CSV_KOALA = "http://tropical.jungle-team.online/epg/guide.csv"
CSV_FILE = "csv_koala.csv"

CATEGORY_PATH = "/usr/share/enigma2/ArtExtra/genero/{}.png"
RATE_PATH = "/usr/share/enigma2/ArtExtra/rate/stars_{}.png"

if os.path.isdir("/media/hdd"):
	path_folder = "/media/hdd/ArtKoala/poster/"
	backdrop_folder = "/media/hdd/ArtKoala/backdrop/"
else:
	path_folder = "/media/usb/ArtKoala/poster/"
	backdrop_folder = "/media/usb/ArtKoala/backdrop/"

class ArtKoala(Renderer):

	def __init__(self):
		Renderer.__init__(self)
		self.pstrNm = ''
		self.evntNm = ''
		self.imageCache = None
		self.intCheck()
		self.nxEvent = 0
		self.renderType = 'poster'
		self.epgcache = eEPGCache.getInstance()

	def intCheck(self):
		try:
			socket.setdefaulttimeout(0.5)
			socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
			return True
		except:
			return False

	GUI_WIDGET = ePixmap
	def changed(self, what):
		try:
			if not self.instance:
				return
			if what[0] == self.CHANGED_CLEAR:
				self.instance.hide()
			if what[0] != self.CHANGED_CLEAR:
				self.delay()
		except:
			pass

	def applySkin(self, desktop, parent):
		self.log("Reading attributes")
		attribs = self.skinAttributes[:]
		for attrib, value in self.skinAttributes:
			if attrib == 'nextEvent':          # 0(current), 1, 2, 3.........
				self.nxEvnt = int(value)
			if attrib == 'renderType' :
				self.renderType = value
		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)

	def showPicture(self):
		self.log("showPicture {}".format(self.renderType))
		try:
			if self.renderType == 'rate':
				self.renderPoster(lambda x, obj = self: obj.getImageRate(x),
								  self.renderImage)
			elif self.renderType == 'poster':
				self.renderPoster(lambda x, obj = self: obj.getImage(x, 'poster'),
				                  self.renderImageScale)
			elif self.renderType == 'backdrop':
				self.renderPoster(lambda x, obj = self: obj.getImage(x, 'backdrop'),
				                  self.renderImageScale)
			elif self.renderType == 'category':
				self.renderPoster(lambda x, obj = self: obj.getImageCategory(x),
								  self.renderImage)
		except Exception as e:
			self.log("showPicture exception {} => {}".format(e, traceback.format_exc()))
			return

	def eventName(self):
		event_name = None
		event_method = getattr(self.source, "event", None)
		self.log("eventName {} => {}".format(self.source, event_method))
		try:
			ref = self.source.service
			events = self.epgcache.lookupEvent(['IBDCTM', (ref.toString(), 0, 1, -1)])
			if events:
				self.log("events 1 {} => {} => {} => {} => {}".format(events[self.nxEvnt][0], events[self.nxEvnt][1], events[self.nxEvnt][2], events[self.nxEvnt][3], events[self.nxEvnt][4]))
				event = events[self.nxEvnt]
				if event:
					event_name = event[4]
		except Exception:
			event = self.source.event
			if event:
				event_name = event.getEventName()
		self.log("eventName => {} ".format(event_name))
		return event_name

	def renderPoster(self, func_get_image, func_render_image):
		try:
			self.log("renderPoster aqui")
			eventName = self.eventName()
			if eventName is not None:
				image_filename = func_get_image(eventName)
				if os.path.exists(image_filename):
					func_render_image(image_filename)
					return
			self.instance.hide()
		except Exception as e:
			self.log("renderPoster exception {} => {}".format(e, traceback.format_exc()))
			return

	def renderImage(self, image_filename):
		self.log("renderImage {}".format(image_filename))
		if image_filename[-4:] == ".png":
			ptr = loadPNG(image_filename)
			if ptr != None:
				self.log("renderImage pixmap {}".format(image_filename))
				self.instance.setPixmap(ptr)
				self.instance.show()
			else:
				self.instance.hide()
		else:
			renderImageScale(image_filename)

	def renderImageScale(self, image_filename):
		try:
			self.log("renderImageScale {}".format(image_filename))
			size = self.instance.size()
			self.picload = ePicLoad()
			sc = AVSwitch().getFramebufferScale()
			if self.picload:
				self.picload.setPara((size.width(),
				size.height(),
				sc[0],
				sc[1],
				False,
				1,
				'#00000000'))
			result = self.picload.startDecode(image_filename, 0, 0, False)
			if result == 0:
				ptr = self.picload.getData()
				if ptr != None:
					self.instance.setPixmap(ptr)
					self.instance.show()
					return
			self.instance.hide()
		except Exception as e:
			self.log("renderImageScale exception {} => {}".format(e, traceback.format_exc()))
			return

	def getImage(self, event_name, image_type):
		event_name = self.normalize_name(event_name)
		filepath = path_folder + datetime.today().strftime('%Y%m%d') + event_name + ".jpg"
		self.downloadPosterFromEPG(event_name, filepath, image_type)
		self.log("get image {} => {} => {}".format(event_name, image_type, filepath))
		return filepath

	def getImageRate(self, event_name):
		event_name = self.normalize_name(event_name)
		self.refreshImageCacheCSV()
		filepath = self.urlRate(event_name)
		self.log("get rate image {} => {}".format(event_name, filepath))
		return filepath

	def getImageCategory(self, event_name):
		event_name = self.normalize_name(event_name)
		self.refreshImageCacheCSV()
		filepath = self.urlCategory(event_name)
		self.log("get category image {} => {}".format(event_name, filepath))
		return filepath

	def downloadPosterFromEPG(self, name, filepath, image_type):
		try:
			self.refreshImageCacheCSV()
			url_poster = self.urlPoster(name, image_type)
			self.log("get cache {} => {}".format(name, url_poster))
			if url_poster != None:
				self.saveFile(url_poster, filepath)
			else:
				return
		except Exception as e:
			self.log("downloadPosterFromEPG exception {} => {}".format(str(e), traceback.format_exc()))
			return

	def urlPoster(self, name, image_type):
		# url_poster = self.imageCache.get(name)
		url_poster = ''
		for k in self.imageCache.keys():
			if k.startswith(name):
				url_poster = self.imageCache.get(k)
				if url_poster:
					url_poster = url_poster.get(image_type)
		return url_poster

	def urlRate(self, name):
		url_rate = RATE_PATH.format("0")
		rate = ''
		for k in self.imageCache.keys():
			if k.startswith(name):
				rate = self.imageCache.get(k)
		if rate is not None and rate != '' and int(rate.get('rate')) > 0 and int(rate.get('rate')) <=5:
			url_rate = RATE_PATH.format(rate.get('rate'))			
		return url_rate

	def urlCategory(self, name):
		url_category = CATEGORY_PATH.format("default")		
		item = None
		for k in self.imageCache.keys():
			if k.startswith(name):
				item = self.imageCache.get(k)
		self.log("urlCategory [{}]".format(item))
		if item is not None:
			categories = re.split("/|-", item['category'])
			for item in categories[::-1]:
				url = CATEGORY_PATH.format(item)
				if os.path.exists(url):
					url_category = url
					break			
		return url_category
		
	def refreshImageCacheCSV(self):
		self.cleanCache()
		epg_csv = self.downloadCSVTV()
		if not self.imageCache:
			self.log("Loading csv file {}".format(epg_csv))
			self.imageCache = {}
			if os.path.exists(epg_csv):
				self.log("Reading csv file {}".format(epg_csv))
				with open(epg_csv) as csv_file:
					csv_reader = csv.reader(csv_file, delimiter=',')
					for row in csv_reader:
						self.log("title {} => rate: {}, poster: {}".format(row[0], row[2], row[1]))
						self.imageCache[row[0]] = { 'poster': str(row[1]), 'rate': str(row[2]), 'category': str(row[3]), 'backdrop': str(row[4]) }


	def downloadCSVTV(self):
		csv_file = datetime.today().strftime('%Y%m%d') + CSV_FILE
		csv_path = path_folder + csv_file
		self.log("downloadCSVTV file {} => {}".format(csv_path, os.path.exists(csv_path)))
		if not os.path.exists(csv_path):
			self.imageCache = None
			self.log("downloadCSVTV {}".format(csv_path))
			self.saveFile(CSV_KOALA, csv_path)
		return csv_path

	def normalize_name(self, name):
		normalized = re.sub("[ ,.:()!¡\?¿]", "_", name).encode().decode('ascii', 'ignore')
		normalized = str(normalized).lower()[0:25]
		index = normalized.find("__")
		if index != -1:
  			normalized = normalized[0:index]
		return normalized

	def saveFile(self, url, filepath):
		if not os.path.isdir(path_folder):
			os.makedirs(path_folder)
		self.log("downloading {} => {}".format(url, filepath))
		with open(filepath,'wb') as f:
			f.write(urlopen(url).read())
			f.close()


	def cleanCache(self):
		os.system("find {} -mindepth 1 -mtime +2 -delete".format(path_folder))

	def log(self, data = ''):
		if not DEBUG:
			return
		try:
			data = str(data)
			fp = open('/tmp/ArtKoalalog', 'a')
			fp.write('\nPoster: ' + data)
			fp.close()
		except:
			pass

	def delay(self):
		self.timer = eTimer()
		self.timer.callback.append(self.showPicture)
		self.timer.start(30, True)
