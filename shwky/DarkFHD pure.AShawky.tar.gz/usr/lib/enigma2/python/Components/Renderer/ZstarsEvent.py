#!/usr/bin/python
# -*- coding: utf-8 -*-

# by digiteng
# v1 04.2020
# 07.2021 start edit lululla
# <ePixmap pixmap="skin_default/icons/starsbar_empty.png" position="1592,738" size="315,42" alphatest="blend" zPosition="2" transparent="1" />
# <widget pixmap="skin_default/icons/starsbar_filled.png" position="1592,738" render="ZstarsEvent" source="session.Event_Now" size="315,42" alphatest="blend" transparent="1" zPosition="3" />
from Components.Renderer.Renderer import Renderer
from Components.VariableValue import VariableValue
from enigma import eSlider
from enigma import eTimer
import os


class ZstarsEvent(VariableValue, Renderer):
    def __init__(self):
        Renderer.__init__(self)
        VariableValue.__init__(self)
        self.timer70 = eTimer()
        self.__start = 0
        self.__end = 100

    GUI_WIDGET = eSlider

    def changed(self, what):
        rtng = 0  # None
        if self.timer70:
            self.timer70.stop()

        if what[0] == self.CHANGED_CLEAR:
            (self.range, self.value) = ((0, 1), 0)
            return
        if what[0] != self.CHANGED_CLEAR:
            # self.delay()
            try:
                self.timer70.callback.append(self.stardel)
            except:
                self.timer70_conn = self.timer70.timeout.connect(self.stardel)
            self.timer70.start(300, False)

    def stardel(self):
        rtng = 0  # None
        event = self.source.event
        if event:
            rating = "/tmp/rating"
            if os.path.exists(rating) and os.stat(rating).st_size > 0:
                with open(rating) as f:
                    try:
                        rating = f.readlines()[0].replace("N/A", "0").replace(" ", "0")
                        if rating:
                            rtng = int(10*(float(rating)))
                        else:
                            rtng = 0
                    except Exception as e:
                        print(e)
        else:
            rtng = 0
        range = 100
        value = rtng
        (self.range, self.value) = ((0, range), value)

    def postWidgetCreate(self, instance):
        instance.setRange(self.__start, self.__end)

    def setRange(self, range):
        (self.__start, self.__end) = range
        if self.instance is not None:
            self.instance.setRange(self.__start, self.__end)

    def getRange(self):
        return self.__start, self.__end

    range = property(getRange, setRange)
