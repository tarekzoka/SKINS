# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Components.config import config, configfile
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
import gettext
import random
from xml.dom.minidom import parseString
from datetime import time
import datetime
import math
import os
import time as time2
from Plugins.Extensions.setupGlass17.weather import PLUGINPATH, ColorLabel, ENA_W, ENA_C, convToC 
from Screens.InputBox import InputBox
from Components.Input import Input
from Components.Sources.List import List
from socket import socket, AF_INET, SOCK_STREAM
from Plugins.Extensions.setupGlass17.txt import EWEA, MoonInfo
from enigma import eTimer
from Tools.LoadPixmap import LoadPixmap
from Plugins.Extensions.setupGlass17.weaUtils import NO_WEATHER_PICON, setFcolor, fixUtf8, calcSun, ignZero, toLocale, ISP38
if ISP38:
	from urllib.request import Request, urlopen
	from urllib.error import URLError, HTTPError
	from urllib.parse import quote, urlencode
	from Plugins.Extensions.setupGlass17.py38 import DG
else:
	from urllib2 import Request, urlopen, URLError, HTTPError
	from urllib import quote, urlencode
	DG = unichr(176).encode("latin-1")
DEFAULT_V = "----"
try:
	if config.plugins.setupGlass17.par49.value:
		E_weather_language = []
		E_weather_language = config.osd.language.value.split("_")
		if os.path.exists(PLUGINPATH + "locale/%s" % (E_weather_language[0])):
			_ = gettext.Catalog('eWeather', PLUGINPATH + 'locale', E_weather_language).gettext
except: pass
ENA_ANIM = False
try:
	if config.plugins.setupGlass17.par66.value:
		ENA_ANIM = True
except: pass
ASTRO = ("sun","moon","mercury","venus","mars","jupiter","saturn","uranus","neptune","pluto")
FORECAST = ("obsdate", "sunrise", "sunset", "txtshort", "weathericon","hightemperature","lowtemperature","windspeed","winddirection","maxuv")
DAY_NIGHT = _("Forecast for")+" "
EW_FILE = "/tmp/eWeather"
ENA_ASTRO = True
try:
	if not config.plugins.setupGlass17.par101.value:
		ENA_ASTRO = False
except: pass
def Writelog(txt):
	log = PLUGINPATH+"e17.txt"
	try:
		f = open(log,"a")
		f.write("%s\n" % str(txt))
		f.close()
	except IOError: pass			
class mainmenu(Screen):

	def __init__(self, session):
		Eskin = """<screen position="0,0" size="1920,1080" title="Enhanced Weather" backgroundColor="black" flags="wfNoBorder" >
			<widget name="init_txt" position="60,0" size="1800,1080" zPosition="9" font="Prive4;75" valign="center" halign="center" foregroundColor="white" backgroundColor="black" transparent="0" />
			<widget name="Lnow1" font="Prive3;28" position="75,45" zPosition="2" size="225,300" valign="top" halign="right" foregroundColor="yellow" backgroundColor="black" transparent="1" />
			<widget name="now1" font="Prive3;28" position="315,45" zPosition="3" size="315,300" valign="top" halign="left" backgroundColor="black" transparent="1" />
			<widget name="Lnow2" font="Prive3;28" position="590,45" zPosition="2" size="225,300" valign="top" halign="right" foregroundColor="yellow" backgroundColor="black" transparent="1" />
			<widget name="now2" font="Prive3;28" position="830,45" zPosition="3" size="315,300" valign="top" halign="left" backgroundColor="black" transparent="1" />
			<widget name="weathertext" font="Prive3;25" position="1020,45" zPosition="3" size="183,90" valign="top" halign="center" foregroundColor="#00d100" backgroundColor="black" transparent="1" />
			<widget name="weathericon_9" position="1057,142" size="108,108" zPosition="0" alphatest="blend" />
			<widget name="sunrise0" font="Prive3;27" position="1252,172" zPosition="1" size="114,30" valign="top" halign="center" foregroundColor="#ffcc00" backgroundColor="black" transparent="1" />		
			<widget name="sunset0" font="Prive3;27" position="1369,172" zPosition="1" size="114,30" valign="top" halign="center" foregroundColor="#ff3300" backgroundColor="black" transparent="1" />		
			<widget name="temperature" font="Prive3;52" position="1252,210" zPosition="2" size="232,75" valign="center" halign="center" foregroundColor="yellow" backgroundColor="black" transparent="1" />
			<widget name="moon_phase" font="Prive3;25" position="1562,105" zPosition="3" size="183,90" valign="top" halign="center" foregroundColor="#00d100" backgroundColor="black" transparent="1" />
			<widget name="moon_pict" position="1603,172" size="100,100" zPosition="0" alphatest="blend" />
			<eLabel position="1252,92" size="599,1" zPosition="8" backgroundColor="#006cbcf0" />
			<ePixmap position="1252,45" size="37,37" pixmap="/usr/share/enigma2/hd_glass17/buttons/green25.png" zPosition="2" alphatest="blend" />
			<ePixmap position="1522,45" size="37,37" pixmap="/usr/share/enigma2/hd_glass17/buttons/blue25.png" zPosition="2" alphatest="blend" />
			<widget name="key_green" position="1305,45" zPosition="3" size="285,60" valign="top" halign="left" font="Prive3;25" transparent="1" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-1,-1" />
			<widget name="key_blue" position="1575,45" zPosition="3" size="285,60" valign="top" halign="left" font="Prive3;25" transparent="1" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-1,-1" />
			<eLabel position="69,289" size="1782,1" zPosition="8" backgroundColor="#006cbcf0" />"""
		Eskin += '<ePixmap position="1252,105" zPosition="0" size="232,60" pixmap="'+PLUGINPATH+'pict/setrise.png" alphatest="blend" />\n'
		offset = 69
		for i in range(0,9):
			a = offset+i*198
			if i != 0:
				Eskin += '<eLabel position="'+str(1+a)+',307" size="1,'+({False:'735', True:'577'}[ENA_ASTRO])+'" zPosition="8" backgroundColor="#006cbcf0" />\n'
			Eskin += '<ePixmap position="'+str(a)+',667" zPosition="0" size="198,'+({False:'381', True:'189'}[ENA_ASTRO])+'" pixmap="'+PLUGINPATH+'pict/ewea'+({False:'3', True:'2'}[ENA_ASTRO])+'.png" alphatest="blend" />\n'
			for x in FORECAST:
				if x == "obsdate":
					Eskin += '<widget name="obsdate_'+str(i)+'" font="Prive3;25" position="'+str(a)+',300" zPosition="6" size="198,60" valign="center" halign="center" foregroundColor="#3399FF" backgroundColor="black" transparent="1" />\n'			
				elif x == "weathericon":
					Eskin += '<widget name="weathericon_'+str(i)+'" position="'+str(45+a)+',366" zPosition="0" size="108,108" alphatest="blend" />\n'
					if not ENA_ASTRO:
						Eskin += '<widget name="wDir_'+str(i)+'" position="'+str(51+a)+',930" zPosition="1" size="96,96" alphatest="blend" />\n'
				elif x == "txtshort":
					Eskin += '<widget name="txtshort_'+str(i)+'" font="Prive3;25" position="'+str(7+a)+',481" zPosition="1" size="183,120" valign="top" halign="center" foregroundColor="#00d100" backgroundColor="black" transparent="1" />\n'			
				elif x == "hightemperature":
					Eskin += '<widget name="hightemperature_'+str(i)+'" font="Prive3;31" position="'+str(99+a)+',615" zPosition="3" size="99,37" valign="center" halign="center" foregroundColor="#cc3300" backgroundColor="black" transparent="1" />\n'			
				elif x == "lowtemperature":
					Eskin += '<widget name="lowtemperature_'+str(i)+'" font="Prive3;31" position="'+str(a)+',615" zPosition="3" size="99,37" valign="center" halign="center" foregroundColor="#00d100" backgroundColor="black" transparent="1" />\n'			
				elif x == "windspeed":
					Eskin += '<widget name="windspeed_'+str(i)+'" font="Prive3;27" position="'+str(30+a)+',703" zPosition="1" size="168,30" valign="top" halign="center" foregroundColor="#26cfc0" backgroundColor="black" transparent="1" />\n'			
				elif x == "maxuv":
					Eskin += '<widget name="maxuv_'+str(i)+'" font="Prive3;27" position="'+str(85+a)+',763" zPosition="1" size="112,30" valign="top" halign="center" foregroundColor="#cc00c0" backgroundColor="black" transparent="1" />\n'			
				elif x == "sunrise":
					Eskin += '<widget name="sunrise_'+str(i)+'" font="Prive3;27" position="'+str(a)+',862" zPosition="1" size="99,30" valign="top" halign="center" foregroundColor="#ffcc00" backgroundColor="black" transparent="1" />\n'			
				elif x == "sunset":
					Eskin += '<widget name="sunset_'+str(i)+'" font="Prive3;27" position="'+str(99+a)+',862" zPosition="1" size="99,30" valign="top" halign="center" foregroundColor="#ff3300" backgroundColor="black" transparent="1" />\n'			
		if ENA_ASTRO:
			Eskin += """<eLabel position="69,904" size="1782,1" zPosition="8" backgroundColor="#006cbcf0" />"""
			a = -1
			for x in ASTRO:
				a += 1
				i = offset+a*177
				Eskin += '<widget name="L_'+x+'" font="Prive3;27" position="'+str(i)+',922" zPosition="1" size="177,30" valign="top" halign="center" foregroundColor="#ff9c00" backgroundColor="black" transparent="1" />\n'
				Eskin += '<ePixmap position="'+str(i)+',967" zPosition="0" size="60,60" pixmap="'+PLUGINPATH+'pict/'+x+'.png" alphatest="blend" />\n'
				Eskin += '<widget name="'+x+'" font="Prive3;27" position="'+str(27+i)+',960" zPosition="1" size="150,75" valign="center" halign="center" foregroundColor="yellow" backgroundColor="black" transparent="1" />\n'
		Eskin += """</screen>""" 
		if config.plugins.setupGlass17.par174.value != "AutoColors" or config.plugins.setupGlass17.par175.value != "AutoColors" or config.plugins.setupGlass17.par176.value != "AutoColors" or config.plugins.setupGlass17.par177.value != "AutoColors":	
			tmp = Eskin.split("\n")
			a = ""
			for i in tmp:
				if 'name="obsdate_' in i and config.plugins.setupGlass17.par174.value != "AutoColors":
					a += setFcolor(i,config.plugins.setupGlass17.par174.value)
				elif 'name="txtshort_' in i and config.plugins.setupGlass17.par175.value != "AutoColors":
					a += setFcolor(i,config.plugins.setupGlass17.par175.value)
				elif 'name="maxuv' in i and config.plugins.setupGlass17.par176.value != "AutoColors":
					a += setFcolor(i,config.plugins.setupGlass17.par176.value)
				elif 'name="windspeed' in i and config.plugins.setupGlass17.par177.value != "AutoColors":
					a += setFcolor(i,config.plugins.setupGlass17.par177.value)
				else:
					a += i + "\n"
			Eskin = a
		self.skin = Eskin
		Screen.__init__(self, session)
		self.now = ("time","city","state","lat","lon","pressure","temperature","realfeel","humidity","weathertext","weathericon","windspeed","winddirection","visibility","precip","uvindex")
		self.Wunits = {"temp":"", "dist":"", "speed":"", "pres":"", "prec":""}
		self["key_green"] = Label(_("Select City"))
		self["key_blue"] = Label(DAY_NIGHT+_("Nighttime"))                                   
		self.dayNight = 0
		self.units = self.chckUnit()
		self.dom = None
		self["weathericon_9"] = Pixmap()
		self["temperature"] = ColorLabel("--")
		self["weathertext"] = Label(DEFAULT_V)
		self["init_txt"] = Label(EWEA)
		self["now1"] = Label(DEFAULT_V)
		self["now2"] = Label(DEFAULT_V)
		self["sunrise0"] = Label(DEFAULT_V)
		self["sunset0"] = Label(DEFAULT_V)
		self['moon_pict'] = Pixmap()
		self['moon_phase'] = Label(DEFAULT_V)
		self["Lnow1"] = Label(_("Updated at")+":\n"+_("Pressure")+":\n"+_("Latitude")+":\n"+_("Longtitude")+":\n"+_("City")+":\n"+_("Location")+":")
		self["Lnow2"] = Label(_("Realfeel")+":\n"+_("Humidity")+":\n"+_("Wind")+":\n"+_("Visibility")+":\n"+_("Precip")+":\n"+_("Uvindex")+":")		
		self.location = "cEUR|SK|LO001|BANSKA BYSTRICA|"	
		self.remainingTime = int(config.plugins.setupGlass17.par87.value)
		a = config.plugins.setupGlass17.par98.value
		if "|" in a:
			if len(a.split("|")) == 5:
				self.location = a
		for x in ASTRO:
			self[x] = Label(DEFAULT_V)
			self["L_"+x] = Label(_(x))
		for i in range(0,9):
			for x in FORECAST:
				if x == "weathericon":
					self["%s_%s" % (x,i)] = Pixmap()
					if not ENA_ASTRO:
						self["wDir_%s" % i] = Pixmap()
				elif x in ("hightemperature","lowtemperature"):
					self["%s_%s" % (x,i)] = ColorLabel(DEFAULT_V)
				elif not x in ("winddirection"):
					self["%s_%s" % (x,i)] = Label(DEFAULT_V)
		self.waitTimer = eTimer()
		try:
			self.waitTimer_conn = self.waitTimer.timeout.connect(self.letsgo)
		except AttributeError:
			self.waitTimer.timeout.get().append(self.letsgo)
		if ENA_ANIM:
			self.animTimer = eTimer()
			try:
				self.animTimer_conn = self.animTimer.timeout.connect(self.__runAnim)
			except AttributeError:
				self.animTimer.timeout.get().append(self.__runAnim)
		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"green": self.greenKey,
			"ok": self.exit,
			"yellow": self.exit,
			"blue": self.blueKey,
			"red": self.exit,
			"cancel": self.exit
		}, -2)
		self.onLayoutFinish.append(self.startWait)

	def chckUnit(self):
		a = config.plugins.setupGlass17.par151.value
		return ({False: a, True:config.plugins.setupGlass17.par98.value[0]}[a == "0"])
		
	def startWait(self):
		self.setTitle(_("Enhanced Weather"))
		for i in range(0,10):
			self["weathericon_%s" % i].instance.setScale(1)
		self['moon_pict'].instance.setScale(1)
		self.waitTimer.start(2000)
		
	def blueKey(self):
		if self.dayNight == 0:
			self.dayNight = 1
			self["key_blue"].setText(DAY_NIGHT+_("Daytime"))
		else:
			self.dayNight = 0
			self["key_blue"].setText(DAY_NIGHT+_("Nighttime"))
		self.letsgo()

	def letsgo(self):
		def fixZero(val):
			if val[0] == "0" and len(val) == 2:
				val = val[1:]
			return val
		def fixTxt(val):
			def chckIn(a):
				if "-" in a and a.endswith("in"):
					b = (a.replace("in","")).split("-")
					if len(b) == 2:
						if b[0].isdigit() and b[1].isdigit():					
							return "%s-%scm" % (round(int(b[0]) * 2.54, 1),round(int(b[1]) * 2.54, 1))
				return _(a)
			val = (val.replace(";",",")).lower()
			if "," in val:
				val = val.split(",")
				ret = ""
				for x in range(0, len(val)):
					ret += chckIn(" ".join(val[x].strip().split())) + "," + " "
				return ret[:-2]
			return chckIn(val)
		def showWicon(val,what="_9"):
			val = fixZero(val)
			if ENA_ANIM:
				path = config.plugins.setupGlass17.par39.value + "/animIconWeather/" + val
				f = None
				try:
					f = len(os.listdir(path))
				except: pass
				x = int(what.replace("_",""))
				self.slide[x] = 0
				self.pics[x] = []
				if f:
					for i in range(0,f):
						self.pics[x].append(LoadPixmap(path+"/"+str(i)+".png"))					
				else:
					self["weathericon"+what].instance.setPixmapFromFile(NO_WEATHER_PICON)
				if len(self.pics[x]) != 0:
					self.ena_s += 1
			else:
				pix = config.plugins.setupGlass17.par39.value + "/weatherIcons/" + str(config.plugins.setupGlass17.par72.value) + "/" + val + ".png"
				if not os.path.isfile(pix):
					pix = NO_WEATHER_PICON
				try:
					self["weathericon"+what].instance.setPixmapFromFile(pix)
				except: pass
			return True	
		def fixDate(d):
			a = d.split("/")
			if len(a) == 3:
				x = datetime.datetime(int(a[2]), int(fixZero(a[0])), int(fixZero(a[1])))
				d = config.plugins.setupGlass17.par185.value
				d = d.replace("%A ","%A\n").replace(" %A","\n%A")
				try:
					if config.plugins.setupGlass17.par188.value:			
						d = d.replace("%d","%-d").replace("%m","%-m")
				except: pass
				d = x.strftime(d)
			return toLocale(d)
		def fixTemp(t):
			tt = ""
			if t[0] != '-' and t[0] != '0':
				tt = '+'
			tt += t
			return tt
		def setColor(x, temp, c):
			if self.units == "f":
				temp = convToC(temp)
				a = convToC(config.plugins.setupGlass17.par149.value)
				b = convToC(config.plugins.setupGlass17.par150.value)
			else:
				a = config.plugins.setupGlass17.par96.value
				b = config.plugins.setupGlass17.par97.value
			if c == 9999:			
				if config.plugins.setupGlass17.par95.value != "None" and temp < a:
					self[x].colorF()
				else:
					self[x].colorW()
			elif c == -9999:			
				if config.plugins.setupGlass17.par95.value != "None" and temp > b:
					self[x].colorF()
				else:
					self[x].colorC()
			else:			
				self[x].colorA(temp)
		def netChck():
			try:
				chck = socket(AF_INET, SOCK_STREAM)
				chck.settimeout(0.8)
				return not bool(chck.connect_ex(('www.accuweather.com', 80)))
			except: pass
			return False
		def download_xml():
			os.system("rm -rf %s" % EW_FILE)
			data = er = None
			if netChck():
				self.units = self.chckUnit()
				location = ({False: self.location, True:self.location[1:]}[self.location[0] in ("c","f")])
				req = Request("http://forecastfox.accuweather.com/adcbin/forecastfox/weather_data.asp?&partner=forecastfox&par=" + str(random.randrange(1000)) + "&location=" + quote(location) + "&metric=" + self.units.replace("f","0").replace("c","1"))
				try:
					response = urlopen(req, timeout = 5)
				except HTTPError as e:
					er = 'Error' + ": " + str(e)
				except URLError as e:
					er = 'Error' + ": " + str(e)
				else:
					data = response.read()
					response.close()								
				if data is not None:
					if ISP38:
						data = data.decode("ascii")
					f = open(EW_FILE, 'a')
					f.write("Hello")
					f.close()
					config.plugins.setupGlass17.par99.value = data
			return data						
		self.waitTimer.stop()
		if ENA_ANIM:
			if self.animTimer.isActive():
				self.animTimer.stop()
			self.slide = {}
			self.pics = {}
			self.ena_s = 0
		tt = {}
		iconsFix = {"01":"32","02":"34","03":"30","04":"30","05":"34","06":"28","07":"26","08":"26","11":"22","12":"11",
								"13":"39","14":"39","15":"35","16":"37","17":"38","18":"12","19":"5","20":"6","21":"7","22":"16",
								"23":"13","24":"25","25":"5","26":"10","29":"5","30":"36","31":"25","32":"23","33":"31","34":"33",
								"35":"33","36":"27","37":"29","38":"27","39":"45","40":"40","41":"47","42":"47","43":"46","44":"46"}
		if self.dom is None:
			data = None
			try:
				lt = int(config.plugins.setupGlass17.par87.value)
				self.remainingTime = lt
				aa = config.plugins.setupGlass17.par152.value
				if config.plugins.setupGlass17.par100.value != self.location:
					config.plugins.setupGlass17.par100.value = self.location 
					data = download_xml()
				elif aa[1] != config.plugins.setupGlass17.par151.value: 
					config.plugins.setupGlass17.par152.value = aa[0] + config.plugins.setupGlass17.par151.value
					data = download_xml()
				elif os.path.isfile(EW_FILE):
					fileTime = int((time2.time() - os.stat(EW_FILE).st_mtime)/60)
					if fileTime >= lt:
						data = download_xml()
					else:
						self.remainingTime = lt - fileTime
						data = config.plugins.setupGlass17.par99.value 
				else:
					data = download_xml()		
			except: return
			if data is not None:
				self.dom = parseString(fixUtf8(data))
			for x in self.Wunits.keys():
				try:
					self.Wunits[x] = str(self.dom.getElementsByTagName(x)[0].firstChild.nodeValue)
				except: pass		
			for x in self.now:
				tt[x] = DEFAULT_V
				try:
					e = str(self.dom.getElementsByTagName(x)[0].firstChild.nodeValue)
					if x == "pressure":
						tt[x] = _(str(self.dom.getElementsByTagName(x)[0].getAttribute("state")))+", "
						if self.Wunits["pres"] == "mb":
							self.Wunits["pres"] = "hPa"
							e = str(int(e)*10)
					elif x == "uvindex":
						tt[x] = str(self.dom.getElementsByTagName(x)[0].getAttribute("index"))+" "
						e = _(e)
					tt[x] = ({False: tt[x]+e, True:e}[tt[x] == DEFAULT_V])
				except: pass                
			self.p0 = iconsFix.get(tt["weathericon"],"3200")
			if ENA_ASTRO:
				for x in ASTRO:
					try:
						self[x].setText("%s\n%s" % (ignZero(str(self.dom.getElementsByTagName("planets")[0].getElementsByTagName(x)[0].getAttribute("rise"))),ignZero(str(self.dom.getElementsByTagName("planets")[0].getElementsByTagName(x)[0].getAttribute("set")))))
					except: pass 	
			try:
				a = tt["temperature"]
				self["temperature"].setText(fixTemp(a)+DG+self.Wunits["temp"])
				setColor("temperature", int(a), ENA_W)
				self["weathertext"].setText(fixTxt(tt["weathertext"]))
				self["now1"].setText(ignZero(tt["time"])+"\n"+tt["pressure"]+self.Wunits["pres"]+"\n"+tt["lat"]+"\n"+tt["lon"]+"\n"+tt["city"]+"\n"+" ".join(tt["state"].strip().split()))
				self["now2"].setText(tt["realfeel"]+DG+self.Wunits["temp"]+"\n"+tt["humidity"]+"\n"+tt["windspeed"]+self.Wunits["speed"]+", "+_(tt["winddirection"])+"\n"+tt["visibility"]+self.Wunits["dist"]+"\n"+tt["precip"]+self.Wunits["prec"]+"\n"+tt["uvindex"]) 
				a,x = MoonInfo()
				self['moon_pict'].instance.setPixmapFromFile(PLUGINPATH+"MoonPict/"+x)
				self['moon_phase'].setText(a)
			except: pass
		try:
			a = showWicon(self.p0)
		except: pass
		ttf = {}
		for i in range(0,9):
			for x in FORECAST:
				ttf["%s_%s" % (x,i)] = DEFAULT_V
				try:
					ttf["%s_%s" % (x,i)] = str(self.dom.getElementsByTagName("day")[i].getElementsByTagName(x)[({False: self.dayNight, True:0}[self.dayNight == 1 and x in ("obsdate", "sunrise", "sunset")])].firstChild.nodeValue)
				except: pass
		for x in ttf.keys():         
			try:
				if "maxuv" in x:
					self[x].setText("max "+ttf[x])
				elif "obsdate" in x:
					self[x].setText(fixDate(ttf[x]))
				elif "hightemperature" in x or "lowtemperature" in x:
					a = ttf[x]
					self[x].setText(fixTemp(a)+DG+self.Wunits["temp"])
					if "hightemperature" in x:
						setColor(x, int(a), ENA_W)
					else:
						setColor(x, int(a), ENA_C)
				elif "windspeed" in x:
					a = ttf[x.replace("windspeed","winddirection")]
					self[x].setText(ttf[x]+self.Wunits["speed"]+", "+_(a))			
					if not ENA_ASTRO:
						self["wDir%s" % x.replace("windspeed","")].instance.setPixmapFromFile(PLUGINPATH+'pict/'+a+'.png')
				elif "weathericon" in x:
					a = showWicon(iconsFix.get(ttf[x],"3200"),x.replace("weathericon",""))   
				elif "txtshort" in x:
					self[x].setText(fixTxt(ttf[x]))
				elif not ("winddirection" in x and "sunset" in x and "sunrise" in x):
					self[x].setText(_(ttf[x]))
			except: pass
		try:
			if tt["lat"] != DEFAULT_V and tt["lon"] != DEFAULT_V:
				for i in range(0,9):
					sunrise, sunset = calcSun(-float(tt["lon"]),float(tt["lat"]),i)
					ttf["sunset_%s" % i] = time.strftime(sunset, '%H:%M')
					ttf["sunrise_%s" % i] = time.strftime(sunrise, '%H:%M')
		except: pass
		try:
			for i in range(0,9):
				self["sunrise_%s" % i].setText(ignZero(ttf["sunrise_%s" % i]))
				self["sunset_%s" % i].setText(ignZero(ttf["sunset_%s" % i]))
			self["sunrise0"].setText(ignZero(ttf["sunrise_0"]))
			self["sunset0"].setText(ignZero(ttf["sunset_0"]))
		except: pass
		del ttf
		del tt
		self["init_txt"].hide()
		if ENA_ANIM and self.ena_s == 10:
			self.animTimer.start(200)
    		
	def __runAnim(self):
		self.animTimer.stop()
		for x in range(0,len(self.slide)):
			a = len(self.pics[x])
			if a != 0:
				if self.slide[x] == a:
					self.slide[x] = 0
				self['weathericon_%s' % x].instance.setPixmap(self.pics[x][self.slide[x]])	
				self.slide[x] += 1
		a = 50
		try:
			a = config.plugins.setupGlass17.par159.value
		except: pass
		self.animTimer.start(a)

	def exit(self):        	
		del self.dom						
		if ENA_ANIM:
			if self.animTimer.isActive():
				self.animTimer.stop()
			self.pics = None	
			self.slide = None	
		self.dom = None		
		self.waitTimer_conn = None
		self.waitTimer = None
		self.close()			

	def greenKey(self):
		self.session.openWithCallback(self.selAnswer, selectCity)

	def selAnswer(self, ret):        
		if ret: 
			if ret != "x" and ret != config.plugins.setupGlass17.par100.value:
				self.location = ret
				config.plugins.setupGlass17.par98.value = ret
				config.plugins.setupGlass17.par98.save()
				configfile.save()
				self.dom = None
				self.letsgo()

class selectCity(Screen):   

	skin = """
	<screen name="selectCity" position="center,center" size="1200,770" title="" backgroundColor="background" >
		<widget source="list" render="Listbox" position="15,15" zPosition="1" size="1170,660" scrollbarMode="showOnDemand" transparent="1" >
      <convert type="TemplatedMultiContent">
				{"template": [ MultiContentEntryText(pos = (0, 0), size = (1170, 60), flags = RT_HALIGN_LEFT, text = 0) ],"fonts": [gFont("Prive3", 32)],"itemHeight": 40}
			</convert>
		</widget>
	<widget name="key_red" position="0,690" size="300,80" zPosition="2" valign="center" halign="center" font="Prive3;33" transparent="1" foregroundColor="red" />
	<widget name="key_yellow" position="300,690" size="300,80" zPosition="2" valign="center" halign="center" font="Prive3;33" transparent="1" foregroundColor="yellow" />
	<widget name="key_blue" position="600,690" size="300,80" zPosition="2" valign="center" halign="center" font="Prive3;33" transparent="1" foregroundColor="blue" />
	<widget name="key_green" position="900,690" size="300,80" zPosition="2" valign="center" halign="center" font="Prive3;33" transparent="1" foregroundColor="green" />
	</screen>"""

	def __init__(self,session):
		self.skin = selectCity.skin
		self.session = session
		Screen.__init__(self, session)
		self.list = []
		self.fileName = "/etc/ewea_city_Code.txt"
		self["key_green"] = Label(_("Select City"))
		self["key_yellow"] = Label(_("Add City")+" (TXT)")
		self["key_red"] = Label(_("Delete City"))
		self["key_blue"] = Label(_("Change Temperature Unit"))
		if config.plugins.setupGlass17.par151.value != "0":
			self["key_blue"].hide()
		self['list'] = List(self.list)	
		self["actions"] = ActionMap(['WizardActions','ColorActions','VirtualKeyboardActions'],
		{
			"green": self.select,
			"ok": self.select,
			"yellow": self.yellowKey,
			"red": self.redKey,
			"blue": self.blueKey,
			'showVirtualKeyboard': self.KeyText,
			"back": self.exit
		})    
		self.onLayoutFinish.append(self.mainFnc)

	def exit(self): 
		self.close('x')
		
	def setWindowTitle(self):
		self.setTitle(_("Select City"))
		
	def select(self):
		selection = self['list'].getCurrent()
		if selection:
			self.close(str(selection[1]))
		self.exit()
		
	def mainFnc(self,w="",d=False):
		self.setWindowTitle()
		self.list = []
		c = 0
		allLines = ""
		try:
			f = open(self.fileName,"r")
			for i in f.readlines():
				value = None
				if "|" in i and "-" in i:
					tmp = (i.replace("\n","")).strip().split("-")
					if len(tmp[1].split("|")) == 5:
						if len(tmp) == 2:
							value = "c"+tmp[1]  
						elif len(tmp) == 3 and tmp[2].lower() in ["c","f"]:
							value = tmp[2].lower()+tmp[1]							
				if value:
					c += 1
					cc = w != "" and w == value
					if not d or (d and not cc):
						if cc:
							value = ({False: "c", True:"f"}[w[0] == "c"])+value[1:]					
						xx = tmp[0]
						if not ISP38:
							xx = xx.encode("utf-8")
						allLines += ({False: i, True:xx+"-"+value[1:]+"-"+value[0]+"\n"}[cc])
						self.list.append((str(c)+".    "+({False: "", True:DG + value[0].upper()}[config.plugins.setupGlass17.par151.value == "0"])+"     " + xx,value))    
			f.close()
			if w != "" and len(self.list) != 0:
				f = open(self.fileName,"w")
				f.write(allLines)
				f.close()
		except: pass
		if len(self.list) == 0:
			self.list = [(_('None city founded'), 'x')]
		self['list'].list = self.list
  		
	def blueKey(self):
		if config.plugins.setupGlass17.par151.value == "0":
			selection = self['list'].getCurrent()
			if selection and selection[1] != "x":
				self.mainFnc(selection[1])

	def redKey(self):
		selection = self['list'].getCurrent()
		if selection and selection[1] != "x":
			self.mainFnc(selection[1],True)
		
	def KeyText(self):
		self.yellowKey(True)

	def yellowKey(self,vc=False):
		if vc:
			from Screens.VirtualKeyBoard import VirtualKeyBoard
			self.session.openWithCallback(self.changeCityAnswer, VirtualKeyBoard, title=_("Please enter a city name")+": ", text="banska bystrica")
		else:
			self.session.openWithCallback(self.changeCityAnswer, InputBox, title=_("Please enter a city name")+": ", text="banska bystrica                   ", maxSize=50, type=Input.TEXT)

	def changeCityAnswer(self, name):
		if name is None and name != "":
			return		
		self.session.openWithCallback(self.callbackNewCity, addSelectCity, name)

	def callbackNewCity(self, ret):
		if ret != "x":
			try:
				f = open(self.fileName,"a")
				f.write(ret+"\n")		
				f.close()
			except: pass				
			self.mainFnc()				
				
class addSelectCity(Screen):
	skin = """<screen position="center,center" size="1200,450" title="Select city">
		<widget source="list" render="Listbox" position="15,15" zPosition="1" size="1200,420" scrollbarMode="showOnDemand" transparent="1" >
      <convert type="TemplatedMultiContent">
				{"template": [ MultiContentEntryText(pos = (0, 0), size = (1170, 60), flags = RT_HALIGN_LEFT, text = 0) ],"fonts": [gFont("Prive3", 32)],"itemHeight": 40}
			</convert>
		</widget>
		</screen>"""

	def __init__(self, session, name):
		Screen.__init__(self, session)
		self.name = name
		self.list = [(_('None city founded'), 'x')]
		self['list'] = List(self.list)
		self['actions'] = ActionMap(['WizardActions', 'ColorActions'], {'back': self.exit,'ok': self.retSel})
		self.onLayoutFinish.append(self.initList)					

	def exit(self): 
		self.close('x')

	def initList(self):
		self.setTitle(_("Select City"))
		req = Request('http://forecastfox.accuweather.com/adcbin/forecastfox/locate_city.asp?partner=forecastfox&location=' + quote(self.name))
		data = er = None
		try:
			response = urlopen(req, timeout = 5)
		except HTTPError as e:
			er = 'Error' + ": " + str(e)
		except URLError as e:
			er = 'Error' + ": " + str(e)
		else:
			data = response.read()
			response.close()
		if data is not None:
			if ISP38:
				data = data.decode("ascii")
			c = []
			dom = ""
			try:
				dom = parseString(fixUtf8(data))
				for x in range(0, int(str(dom.getElementsByTagName("citylist")[0].getAttribute("extra_cities"))) + int(str(dom.getElementsByTagName("citylist")[0].getAttribute("us"))) + int(str(dom.getElementsByTagName("citylist")[0].getAttribute("intl")))):
					a = str(dom.getElementsByTagName("location")[x].getAttribute("location"))
					if "|" in a:
						if len(a.split("|")) == 5:
							tt = str(dom.getElementsByTagName("location")[x].getAttribute("city"))
							c.append((tt + ", " + str(dom.getElementsByTagName("location")[x].getAttribute("state")), tt+"-"+a+"-c"))
			except: pass
			if len(c) != 0:
				self.list = c
			del dom
			del c			
		self['list'].list = self.list  
  
	def retSel(self):  
		del self.list
		selected = self['list'].getCurrent()
		if selected:
			self.close(selected[1])
		else: 
			self.close('x')
