# -*- coding: utf-8 -*-
import os
import sys
import re
import requests
import threading
from PIL import Image

PY3 = (sys.version_info[0] == 3)
try:
	if PY3:
		from urllib.parse import quote
	else:
		from urllib2 import quote
except:
	pass


try:
	from Components.config import config
	lng = config.osd.language.value
except:
	lng = None
	pass


tmdb_api = "3c3efcf47c3577558812bb9d64019d65"
tvdb_api = "a99d487bb3426e5f3a60dea6d3d3c7ef"

isz="185,278"

class PosterXDownloadThread(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)
		self.checkMovie = ["film", "movie", "фильм", "кино", "ταινία", "película", "cinéma", "cine", "cinema", "filma"]
		self.checkTV = [ "serial", "series", "serie", "serien", "série", "séries", "serious",
			"folge", "episodio", "episode", "épisode", "l'épisode", "ep.",  "comédie", "animation",
			"staffel", "soap", "doku", "tv", "talk", "show", "news", "factual", "entertainment", "telenovela", 
			"dokumentation", "dokutainment", "documentary", "informercial", "information", "sitcom", "reality", 
			"program", "magazine", "mittagsmagazin", "т/с", "м/с", "сезон", "с-н", "эпизод", "сериал", "серия",
			"actualité", "discussion", "interview", "débat", "émission", "divertissement", "jeu", "magasine",
			"information", "météo", "journal", "sport", "culture", "infos", "feuilleton", "téléréalité",
			"société", "clips", "concert", "santé", "éducation", "variété" ]

	def search_tmdb(self,dwn_poster,title,shortdesc,fulldesc,channel=None):
		try:
			fd = "{}\n{}".format(shortdesc,fulldesc)
			srch = "multi"
			year = None
			url_tmdb = ""
			poster = None
			
			try:
				if re.findall('19\d{2}|20\d{2}', title):
					year = re.findall('19\d{2}|20\d{2}', fd)[1]
				else:
					year = re.findall('19\d{2}|20\d{2}', fd)[0]					
			except:
				year = ''
				pass
			
			for i in self.checkMovie:
				if i in fd.lower():
					srch = "movie"
					break
			
			if srch != "movie":
				for i in self.checkTV:
					if i in fd.lower():
						srch = "tv"
						break

			url_tmdb = "https://api.themoviedb.org/3/search/{}?api_key={}&query={}".format(srch, tmdb_api, quote(title))
			if year:
				url_tmdb += "&year={}".format(year)
			if lng:
				url_tmdb += "&language={}".format(lng[:-3])
			
			
			poster = requests.get(url_tmdb).json()
			if poster and poster['results'] and poster['results'][0] and poster['results'][0]['poster_path']:
				url_poster = "https://image.tmdb.org/t/p/w{}{}".format(str(isz.split(",")[0]), poster['results'][0]['poster_path'])
				self.savePoster(dwn_poster, url_poster)
				return True, "[SUCCESS : tmdb] {} => {} => {}".format(title,url_tmdb,url_poster)
			else:
				return False, "[SKIP : tmdb] {} => {} (Not found)".format(title,url_tmdb)
		except Exception as e:
			if os.path.exists(dwn_poster):
				os.remove(dwn_poster)
			return False, "[ERROR : tmdb] {} => {} ({})".format(title,url_tmdb,str(e))
				
	def search_molotov_google(self,dwn_poster,title,shortdesc,fulldesc,channel=None):
		try:
			url_mgoo = ''
			headers = {"User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"}
			fd = "{}\n{}".format(shortdesc,fulldesc)

			ptitle = self.UNAC(title)
			if channel:
				pchannel = self.UNAC(channel).replace(' ','')
			poster = None
			srch = 'TV'
			issc = -1
			issp = -1
			issi = -1
			imsg = ''

			for i in self.checkMovie:
				if i in fd.lower():
					srch = "Movie"
					break

			url_mgoo = "site:molotov.tv+"+quote(title)
			url_mgoo = "https://www.google.com/search?q={}&tbm=isch&tbs=ift:jpg%2Cisz:m".format(url_mgoo)
			ff = requests.get(url_mgoo, stream=True, headers=headers).text
			ff = ff.encode('utf-8')

			plst = re.findall('\],\["https://(.*?)",\d+,\d+].*?"https://.*?","(.*?)"', ff)
			plti = None
			for pl in plst:
				pltc=re.findall('(.*?) en[ ]+Streaming (?:.* Replay )?(?:sur)?(.*?)-[ ]+Molotov.tv',pl[1])
				issc += 1
				if pltc:
					if pltc[0][0]:
						plt = self.UNAC(pltc[0][0])
					else:
						plt = ''
					if pltc[0][1]:
						plc = self.UNAC(pltc[0][1]).replace(' ','')
					else:
						plc=''
				else:
					plt=''
					plc=''
				if ptitle==plt and channel and plc.find(pchannel)>=0:
					imsg = "Found exact title & channel [{}]".format(issc)
					poster=pl[0]
					break
				if ptitle==plt and issp<100:
					issp = 100
					plti = plt
					issi = issc
				elif self.PMATCH(ptitle,plt) > issp:
					issp = self.PMATCH(ptitle,plt)
					plti = plt
					issi = issc
				#print("        {}. [{}-{}] ({}-{}) -> {} {}% ({})".format(issc,ptitle,plt,channel,plc,plti,issp,issi))	#######
				if issc > 9:
					break
			if not poster and issp==100:
				imsg = "Found exact title [{}/{}] : {}".format(issi,issc,plti)
				poster=plst[issi][0]
			if not poster and srch!="Movie":
				if issp>0:			
					imsg = "Select best title {}% [{}/{}] : {}".format(issp,issi,issc,plti)
					poster=plst[issi][0]
#				elif issi==0:
#					imsg = "Select first channel [0/{}] : {}".format(issc,plti)
#					poster=plst[0][0]
				
			if poster:
				poster = re.sub('/\d+x\d+/',"/"+re.sub(',','x',isz)+"/",poster)
				url_poster = "https://{}".format(poster)
				self.savePoster(dwn_poster, url_poster)
				return True, "[SUCCESS : molotov-google] {} => {} => {} => {}".format(title,imsg,url_mgoo,url_poster)
			else:
				imsg = "Skip title (type:{}) {}% [{}/{}] : {}".format(srch,issp,issi,issc,plti)
				return False, "[SKIP : molotov-google] {} => {} => {}".format(title,imsg,url_mgoo)
		except Exception as e:
			if os.path.exists(dwn_poster):
				os.remove(dwn_poster)
			return False, "[ERROR : molotov-google] {} => {} ({})".format(title,url_mgoo,str(e))

	def search_google(self,dwn_poster,title,shortdesc,fulldesc,channel=None):
		try:
			headers = {"User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"}
			fd = "{}\n{}".format(shortdesc,fulldesc)

			url_poster = ''
			year = None
			
			try:
				if re.findall('19\d{2}|20\d{2}', title):
					year = re.findall('19\d{2}|20\d{2}', fd)[1]
				else:
					year = re.findall('19\d{2}|20\d{2}', fd)[0]					
			except:
				year = ''
				pass
			
			url_google = quote(title)
			if channel and title.find(channel)<0:
				url_google += "+{}".format(quote(channel))
			if year:
				url_google += "+{}".format(year)

			url_google = "https://www.google.com/search?q={}&tbm=isch&tbs=ift:jpg%2Cisz:m".format(url_google)
			ff = requests.get(url_google, stream=True, headers=headers).text
			
			posterlst = re.findall('\],\["https://(.*?)",\d+,\d+]', ff)		
			for pl in posterlst:
				url_poster = "https://{}".format(pl)
				url_poster = re.sub(r"\\u003d", "=", url_poster)
				self.savePoster(dwn_poster, url_poster)
				if self.verifyPoster(dwn_poster):
					poster = pl
					break

			if poster:
				return True, "[SUCCESS : google] {} => {} => {}".format(title,url_google,url_poster)
			else:				
				return False, "[SKIP : google] {} => {} => {} (Not found)".format(title,url_google,url_poster)
				
			
		except Exception as e:
			if os.path.exists(dwn_poster):
				os.remove(dwn_poster)				
			return False, "[ERROR : google] {} => {} => {} ({})".format(title,url_google,url_poster,str(e))

	def search_tvdb(self,dwn_poster,title,shortdesc,fulldesc,channel=None):
		try:
			url_tvdbg = "https://thetvdb.com/api/GetSeries.php?seriesname={}".format(quote(title))
			url_read = requests.get(url_tvdbg).text
			series_id = re.findall('<seriesid>(.*?)</seriesid>', url_read)
			poster = ""
			if series_id and series_id[0]:
				url_tvdb = "https://thetvdb.com/api/{}/series/{}".format(tvdb_api, series_id[0])
				if lng:
					url_tvdb += "/{}".format(lng[:-3])
				else:
					url_tvdb += "/en"
				
				url_read = requests.get(url_tvdb).text
				poster = re.findall('<poster>(.*?)</poster>', url_read)
				
			if poster and poster[0]:
				url_poster = "https://artworks.thetvdb.com/banners/{}".format(poster[0])
				self.savePoster(dwn_poster, url_poster)
				return True, "[SUCCESS : tvdb] {} => {} => {} => {}".format(title,url_tvdbg,url_tvdb,url_poster)
			else:
				return False, "[SKIP : tvdb] {} => {} (Not found)".format(title,url_tvdbg)
				
		except Exception as e:
			if os.path.exists(dwn_poster):
				os.remove(dwn_poster)
			return False, "[ERROR : tvdb] {} => {} ({})".format(title,url_tvdbg,str(e))
			
	def search_imdb(self,dwn_poster,title,shortdesc,fulldesc,channel=None):
		try:
			url_poster = None
			fd = "{}\n{}".format(shortdesc,fulldesc)
			year = ''
			try:
				if re.findall('19\d{2}|20\d{2}', title):
					year = re.findall('19\d{2}|20\d{2}', fd)[1]
				else:
					year = re.findall('19\d{2}|20\d{2}', fd)[0]					
			except:
				year = ''
				pass
			
			url_mimdb = "https://m.imdb.com/find?q={}".format(quote(title))
			url_read = requests.get(url_mimdb).text
			rc=re.compile('<img src="(.*?)".*?\((\d+)\)(\s\(.*?\))?',re.DOTALL)
			
			url_imdb = rc.findall(url_read)
			for imdb in url_imdb:
				imdb = list(imdb)
				if year=='':
					imdb[1] = ''
				imdb_poster=re.search("(.*?)._V1_.*?.jpg",imdb[0])
				if imdb_poster:
					if imdb[2]=='':
						if year==imdb[1]:
							url_poster = "{}._V1_UY278,1,185,278_AL_.jpg".format(imdb_poster.group(1)) #_V1_UY278_CR0,1,185,278_AL_.jpg
							break
						elif int(year)-1==int(imdb[1]) or int(year)+1==int(imdb[1]):
							url_poster = "{}._V1_UY278,1,185,278_AL_.jpg".format(imdb_poster.group(1)) #_V1_UY278_CR0,1,185,278_AL_.jpg
						
			if url_poster:
				self.savePoster(dwn_poster, url_poster)
				return True, "[SUCCESS : imdb] {} => {} => {}".format(title,url_mimdb,url_poster)
			else:
				return False, "[SKIP : imdb] {} => {} (Not found)".format(title,url_mimdb)
		except Exception as e:
			if os.path.exists(dwn_poster):
				os.remove(dwn_poster)
			return False, "[ERROR : imdb] {} => {} ({})".format(title,url_mimdb,str(e))

	def savePoster(self, dwn_poster, url_poster):
		with open(dwn_poster,'wb') as f:
			f.write(requests.get(url_poster, stream=True, allow_redirects=True, verify=False).content)
			f.close()

	def verifyPoster(self, dwn_poster):
		try:
			img = Image.open(dwn_poster)
			img.verify()
		except Exception as e:
			try:
				os.remove(dwn_poster)
			except:
				pass
			return None
		return True

	def UNAC(self,string):
		if type(string) is not unicode:
			string = unicode(string, encoding='utf-8')
		string = re.sub(r"[-,!/\.\":]",' ',string)
		string = re.sub(u"[ÀÁÂÃÄàáâãäåª]", 'a', string)
		string = re.sub(u"[ÈÉÊËèéêë]", 'e', string)
		string = re.sub(u"[ÍÌÎÏìíîï]", 'i', string)
		string = re.sub(u"[ÒÓÔÕÖòóôõöº]", 'o', string)
		string = re.sub(u"[ÙÚÛÜùúûü]", 'u', string)
		string = re.sub(u"[Ññ]", 'n', string)
		string = re.sub(u"[Çç]", 'c', string)
		string = re.sub(u"[Ÿýÿ]", 'y', string)
		string = re.sub(r"[^a-zA-Z0-9 ']","", string)
		string = string.lower()
		string = re.sub(u"u003d", "", string)
		string = re.sub(r'\s{1,}', ' ', string)
		string = string.strip()	
		return string

	def PMATCH(self,textA,textB):
		if not textB or textB=='' or not textA or textA=='':
			return 0
		textA = textA.split()
		textB = textB.split()
		cB = 0
		for idB in textA:
			if idB in textB:
				cB += 1
		return 100*cB/len(textA)

# Manual test
#tpx = PosterXDownloadThread()
#dwn_poster = "test_poster.jpg"
#val, log = tpx.search_molotov_google(dwn_poster,"title_test","give_sort_desc","give_long_desc_plus_date_2022","canal")
#val, log = tpx.search_imdb(dwn_poster,"title_test","give_sort_desc","give_long_desc_plus_date_2022")	
#val, log = tpx.search_tmdb(dwn_poster,"title_test","give_sort_desc","give_long_desc_plus_date_2022")	
#val, log = tpx.search_tvdb(dwn_poster,"title_test","give_sort_desc","give_long_desc_plus_date_2022")	
#val, log = tpx.search_google(dwn_poster,"title_test","give_sort_desc","give_long_desc_plus_date_2022","canal")	
#print(log)	
